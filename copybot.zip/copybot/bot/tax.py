"""UK Capital Gains Tax export.

Applies HMRC share-matching rules per token: same-day, then "bed and breakfast" (re-buys
within 30 days after a sale), then the Section 104 pool. Gas is added to acquisition cost and
deducted from disposal proceeds. This is an ESTIMATE to hand to tax software or an accountant.
"""
from __future__ import annotations

import csv
from collections import defaultdict
from datetime import date, datetime, timedelta, timezone
from pathlib import Path


def tax_year(d: date) -> str:
    start = d.year if (d.month, d.day) >= (4, 6) else d.year - 1
    return f"{start}/{str(start + 1)[2:]}"


def match_disposals(fills: list[dict]) -> list[dict]:
    """fills: [{ts, asset, side, qty, gbp_value, gbp_fee}] -> per-day disposal rows."""
    by_asset: dict[str, list[dict]] = defaultdict(list)
    for f in fills:
        by_asset[f["asset"]].append(f)
    results: list[dict] = []
    for asset, rows in by_asset.items():
        days: dict[date, dict] = defaultdict(lambda: {"aq": 0.0, "ac": 0.0, "dq": 0.0, "dp": 0.0})
        for f in rows:
            d = datetime.fromtimestamp(f["ts"], tz=timezone.utc).date()
            if f["side"] == "buy":
                days[d]["aq"] += f["qty"]
                days[d]["ac"] += f["gbp_value"] + f["gbp_fee"]
            else:
                days[d]["dq"] += f["qty"]
                days[d]["dp"] += f["gbp_value"] - f["gbp_fee"]
        order = sorted(days)
        disp: dict[date, dict] = {d: {"qty": v["dq"], "proceeds": v["dp"], "cost": 0.0, "rules": [], "left": v["dq"]}
                                  for d, v in days.items() if v["dq"] > 0}

        def take(d: date, qty: float) -> float:
            v = days[d]
            if v["aq"] <= 0:
                return 0.0
            cost = v["ac"] * qty / v["aq"]
            v["ac"] -= cost
            v["aq"] -= qty
            return cost

        # 1. same day
        for d in order:
            if d in disp and days[d]["aq"] > 0:
                m = min(disp[d]["left"], days[d]["aq"])
                disp[d]["cost"] += take(d, m)
                disp[d]["left"] -= m
                disp[d]["rules"].append("same-day")
        # 2. bed & breakfast: acquisitions in the 30 days AFTER the disposal
        for d in order:
            if d not in disp or disp[d]["left"] <= 1e-12:
                continue
            for e in order:
                if d < e <= d + timedelta(days=30) and days[e]["aq"] > 0 and disp[d]["left"] > 1e-12:
                    m = min(disp[d]["left"], days[e]["aq"])
                    disp[d]["cost"] += take(e, m)
                    disp[d]["left"] -= m
                    if "30-day" not in disp[d]["rules"]:
                        disp[d]["rules"].append("30-day")
        # 3. section 104 pool
        pool_q = pool_c = 0.0
        for d in order:
            if days[d]["aq"] > 0:
                pool_q += days[d]["aq"]
                pool_c += days[d]["ac"]
            if d in disp and disp[d]["left"] > 1e-12:
                m = min(disp[d]["left"], pool_q)
                c = pool_c * m / pool_q if pool_q else 0.0
                pool_q -= m
                pool_c -= c
                disp[d]["cost"] += c
                disp[d]["left"] -= m
                disp[d]["rules"].append("s104")
        for d, v in sorted(disp.items()):
            results.append({"date": d.isoformat(), "tax_year": tax_year(d), "asset": asset, "qty": v["qty"],
                            "proceeds_gbp": round(v["proceeds"], 2), "cost_gbp": round(v["cost"], 2),
                            "gain_gbp": round(v["proceeds"] - v["cost"], 2), "rules": "+".join(v["rules"]),
                            "unmatched_qty": round(v["left"], 12)})
    return sorted(results, key=lambda r: r["date"])


def export(db, out_dir: Path, mode: str = "live") -> tuple[Path, Path, dict[str, float]]:
    rows = db.q("SELECT * FROM fills WHERE mode=? ORDER BY ts", (mode,))
    fills = [{"ts": r["ts"], "asset": f"{r['symbol']} ({r['chain']}:{r['token']})", "side": r["side"],
              "qty": r["qty"], "gbp_value": r["value_usd"] * r["gbp_per_usd"],
              "gbp_fee": (r["fee_usd"] or 0) * r["gbp_per_usd"]} for r in rows]
    out_dir.mkdir(parents=True, exist_ok=True)
    ledger = out_dir / f"trade_ledger_{mode}.csv"
    with ledger.open("w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["date_utc", "type", "asset", "chain", "token_address", "quantity", "price_usd", "value_usd",
                    "fee_usd", "gbp_per_usd", "value_gbp", "fee_gbp", "tx_hash"])
        for r in rows:
            w.writerow([datetime.fromtimestamp(r["ts"], tz=timezone.utc).isoformat(), r["side"], r["symbol"],
                        r["chain"], r["token"], r["qty"], r["price_usd"], r["value_usd"], r["fee_usd"],
                        r["gbp_per_usd"], round(r["value_usd"] * r["gbp_per_usd"], 2),
                        round((r["fee_usd"] or 0) * r["gbp_per_usd"], 2), r["tx_hash"] or ""])
    disposals = match_disposals(fills)
    cgt = out_dir / f"cgt_disposals_{mode}.csv"
    with cgt.open("w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=list(disposals[0].keys()) if disposals else
                           ["date", "tax_year", "asset", "qty", "proceeds_gbp", "cost_gbp", "gain_gbp", "rules", "unmatched_qty"])
        w.writeheader()
        w.writerows(disposals)
    totals: dict[str, float] = defaultdict(float)
    for d in disposals:
        totals[d["tax_year"]] += d["gain_gbp"]
    return ledger, cgt, dict(totals)
