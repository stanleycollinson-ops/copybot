"""Leader scoring from historical trades. Pure functions."""
from __future__ import annotations

import statistics
from collections import defaultdict, deque
from dataclasses import dataclass, field
from typing import Iterable, Optional

from .models import LeaderTrade


@dataclass
class RoundTrip:
    token: str
    buy_ts: float
    sell_ts: float
    cost_usd: float
    proceeds_usd: float

    @property
    def pnl(self) -> float:
        return self.proceeds_usd - self.cost_usd

    @property
    def hold_s(self) -> float:
        return self.sell_ts - self.buy_ts


@dataclass
class LeaderMetrics:
    n_trades: int = 0
    n_closed: int = 0
    realised_pnl_usd: float = 0.0
    pnl_30d_usd: float = 0.0
    win_rate: float = 0.0
    profit_factor: float = 0.0
    max_drawdown_usd: float = 0.0
    peak_pnl_usd: float = 0.0
    trades_per_day: float = 0.0
    median_hold_s: float = 0.0
    median_trade_usd: float = 0.0
    largest_win_share: float = 0.0
    wash_share: float = 0.0
    sniper_share: Optional[float] = None
    copy_return_pct: Optional[float] = None  # from replay
    copy_n: int = 0
    flags: list[str] = field(default_factory=list)
    score: float = 0.0


def round_trips(trades: Iterable[LeaderTrade]) -> list[RoundTrip]:
    """FIFO-match buys and sells per token. Only legs with known USD value are used."""
    lots: dict[str, deque] = defaultdict(deque)  # token -> [qty, cost_per_unit, ts]
    out: list[RoundTrip] = []
    for t in sorted(trades, key=lambda x: x.ts):
        if t.quote_usd is None or t.token_amount <= 0:
            continue
        if t.side == "buy":
            lots[t.token].append([t.token_amount, t.quote_usd / t.token_amount, t.ts])
        else:
            remaining = t.token_amount
            px = t.quote_usd / t.token_amount
            while remaining > 1e-12 and lots[t.token]:
                lot = lots[t.token][0]
                q = min(lot[0], remaining)
                out.append(RoundTrip(t.token, lot[2], t.ts, q * lot[1], q * px))
                lot[0] -= q
                remaining -= q
                if lot[0] <= 1e-12:
                    lots[t.token].popleft()
    return out


def compute_metrics(trades: list[LeaderTrade], scfg: dict, now: float,
                    pool_created: Optional[dict[str, float]] = None) -> LeaderMetrics:
    m = LeaderMetrics()
    m.n_trades = len(trades)
    if not trades:
        m.flags.append("no trades")
        return m
    rts = round_trips(trades)
    m.n_closed = len(rts)
    span_days = max((max(t.ts for t in trades) - min(t.ts for t in trades)) / 86400, 1.0)
    m.trades_per_day = len(trades) / span_days
    buys_usd = [t.quote_usd for t in trades if t.side == "buy" and t.quote_usd]
    m.median_trade_usd = statistics.median(buys_usd) if buys_usd else 0.0

    if rts:
        pnls = [r.pnl for r in rts]
        m.realised_pnl_usd = sum(pnls)
        m.pnl_30d_usd = sum(r.pnl for r in rts if r.sell_ts >= now - 30 * 86400)
        wins = [p for p in pnls if p > 0]
        losses = [-p for p in pnls if p < 0]
        m.win_rate = len(wins) / len(pnls)
        m.profit_factor = (sum(wins) / sum(losses)) if losses else (3.0 if wins else 0.0)
        m.median_hold_s = statistics.median(r.hold_s for r in rts)
        m.largest_win_share = (max(wins) / sum(wins)) if wins else 0.0
        m.wash_share = sum(1 for r in rts if r.hold_s < 60 and abs(r.pnl) < 0.01 * max(r.cost_usd, 1)) / len(rts)
        cum = peak = dd = 0.0
        for r in sorted(rts, key=lambda x: x.sell_ts):
            cum += r.pnl
            peak = max(peak, cum)
            dd = max(dd, peak - cum)
        m.max_drawdown_usd, m.peak_pnl_usd = dd, peak

    if pool_created:
        buys = [t for t in trades if t.side == "buy" and t.token in pool_created]
        if buys:
            win = scfg.get("sniper_window_s", 600)
            m.sniper_share = sum(1 for t in buys if t.ts - pool_created[t.token] < win) / len(buys)

    # ---------- exclusion flags ----------
    if m.n_closed < scfg["min_closed_trades"]:
        m.flags.append("not enough closed trades")
    if m.trades_per_day > scfg["bot_trades_per_day"] or (m.n_closed and m.median_hold_s < scfg["bot_median_hold_s"]):
        m.flags.append("bot/MEV-like activity")
    if m.sniper_share is not None and m.sniper_share > 0.5:
        m.flags.append("sniper/insider (buys at launch)")
    if m.wash_share > 0.3:
        m.flags.append("wash-trading pattern")
    if m.largest_win_share > scfg["one_hit_share"] and m.n_closed >= 3:
        m.flags.append("one-hit wonder")
    if m.realised_pnl_usd <= 0:
        m.flags.append("not profitable")
    m.score = score_metrics(m)
    return m


def score_metrics(m: LeaderMetrics) -> float:
    s = 0.0
    s += min(m.profit_factor, 3.0) / 3.0 * 20
    s += max(0.0, min((m.win_rate - 0.3) / 0.4, 1.0)) * 15
    s += 10 if m.realised_pnl_usd > 0 else 0
    s += 10 if (m.pnl_30d_usd > 0 and m.realised_pnl_usd > 0) else 0
    if m.peak_pnl_usd > 0:
        s += (1 - min(m.max_drawdown_usd / m.peak_pnl_usd, 1.0)) * 10
    s += 10 if 0.2 <= m.trades_per_day <= 10 else 0
    if m.copy_return_pct is None:
        s += 10  # unknown copyability: neutral
    else:
        s += max(0.0, min(m.copy_return_pct / 10, 1.0)) * 25
    if m.flags:
        s = min(s, 30.0)  # flagged leaders can never be promoted
    return round(s, 1)
