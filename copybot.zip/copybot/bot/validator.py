"""Trade validation: hard safety gates, then a 0-100 quality score. Pure function, no network,
so the improvement job can re-run past decisions under different thresholds."""
from __future__ import annotations

from .models import Decision, Snapshot


def estimate_cost_pct(size_usd: float, liquidity_usd: float | None, dex_fee_pct: float, gas_usd: float) -> float:
    """Round-trip cost (buy now + sell later) as % of trade size.
    Price impact for a constant-product pool ~= 2 * size / total liquidity per swap."""
    if size_usd <= 0:
        return 100.0
    impact_pct = (2 * size_usd / liquidity_usd * 100) if liquidity_usd else 5.0
    return 2 * (dex_fee_pct + impact_pct) + 2 * gas_usd / size_usd * 100


def validate(s: Snapshot, vcfg: dict) -> Decision:
    reasons: list[str] = []

    # ---------- hard gates: token safety ----------
    if s.token in vcfg.get("token_denylist", []):
        reasons.append("token on denylist")
    if s.is_honeypot:
        reasons.append("honeypot")
    if s.cannot_sell_all:
        reasons.append("cannot sell all")
    if s.owner_change_balance:
        reasons.append("owner can change balances")
    if s.transfer_pausable:
        reasons.append("transfers pausable")
    if s.slippage_modifiable:
        reasons.append("tax modifiable")
    if s.is_blacklisted:
        reasons.append("has blacklist")
    if s.hidden_owner:
        reasons.append("hidden owner")
    if s.is_open_source is False:
        reasons.append("contract not verified")
    if s.is_honeypot is None and s.is_open_source is None:
        reasons.append("no safety data")
    if s.buy_tax_pct is not None and s.buy_tax_pct > vcfg["max_buy_tax_pct"]:
        reasons.append(f"buy tax {s.buy_tax_pct:.1f}%")
    if s.sell_tax_pct is not None and s.sell_tax_pct > vcfg["max_sell_tax_pct"]:
        reasons.append(f"sell tax {s.sell_tax_pct:.1f}%")
    if s.top10_holder_pct is not None and s.top10_holder_pct > vcfg["max_top10_holder_pct"]:
        reasons.append(f"top-10 wallets hold {s.top10_holder_pct:.0f}%")
    if s.token_age_h is None or s.token_age_h < vcfg["min_token_age_h"]:
        reasons.append("token too new" if s.token_age_h is not None else "token age unknown")

    # ---------- hard gates: liquidity and cost ----------
    if s.liquidity_usd is None or s.liquidity_usd < vcfg["min_liquidity_usd"]:
        reasons.append(f"liquidity ${s.liquidity_usd or 0:,.0f} below minimum")
    cost = estimate_cost_pct(s.trade_size_usd, s.liquidity_usd, vcfg["dex_fee_pct"], s.gas_usd_per_swap)
    if cost > vcfg["max_cost_pct"]:
        reasons.append(f"round-trip cost {cost:.1f}% too high")

    # ---------- hard gates: timing ----------
    if s.current_price is None:
        reasons.append("no current price")
    if s.delay_s > vcfg["max_delay_s"]:
        reasons.append(f"signal {s.delay_s:.0f}s old")
    if s.leader_price and s.current_price:
        move = (s.current_price / s.leader_price - 1) * 100
        if move > vcfg["max_price_move_pct"]:
            reasons.append(f"price already up {move:.1f}% since leader")

    # ---------- hard gates: leader context ----------
    if s.leader_median_trade_usd and s.leader_trade_usd is not None:
        if s.leader_trade_usd < vcfg["test_buy_ratio"] * s.leader_median_trade_usd:
            reasons.append("looks like a test buy")
    if s.leader_recent_sells_1h >= vcfg["max_leader_recent_sells"]:
        reasons.append(f"leader sold {s.leader_recent_sells_1h} tokens in last hour")

    # ---------- soft score ----------
    comp: dict[str, float] = {}
    comp["leader"] = max(0.0, min(s.leader_score, 100.0)) / 100 * 30
    if s.leader_median_trade_usd and s.leader_trade_usd:
        ratio = s.leader_trade_usd / s.leader_median_trade_usd
        comp["conviction"] = min(ratio, 2.0) / 2.0 * 15
    else:
        comp["conviction"] = 7.0
    comp["consensus"] = {1: 5.0, 2: 10.0}.get(s.consensus_independent, 15.0 if s.consensus_independent > 2 else 0.0)
    comp["market"] = 10.0 if s.btc_risk_on else (5.0 if s.btc_risk_on is None else 2.0)
    mom = 0.0
    if s.volume_24h_usd and s.liquidity_usd:
        mom += min(s.volume_24h_usd / s.liquidity_usd, 2.0) / 2.0 * 10
    if s.price_change_h1 is not None and s.price_change_h1 > 0:
        mom += 5
    comp["momentum"] = mom
    safety = 0.0
    if s.lp_locked_pct is not None and s.lp_locked_pct >= 80:
        safety += 5
    if s.top10_holder_pct is not None:
        safety += max(0.0, 1 - s.top10_holder_pct / 60) * 5
    if s.token_age_h is not None:
        safety += min(s.token_age_h / 168, 1.0) * 5
    comp["safety"] = safety

    score = sum(comp.values())
    if not s.leader_niche_match:
        score *= vcfg["niche_penalty"]
        comp["niche_penalty"] = vcfg["niche_penalty"]
    approved = not reasons and score >= vcfg["min_score"]
    return Decision(approved=approved, score=round(score, 1), reasons=reasons, components=comp, est_cost_pct=round(cost, 2))
