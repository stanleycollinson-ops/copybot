"""Turn raw transfers into leader buy/sell trades. Pure functions, no network."""
from __future__ import annotations

from collections import defaultdict
from typing import Callable, Iterable, Optional

from .models import LeaderTrade, TokenTransfer

TRANSFER_TOPIC = "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef"
STABLES = {"USDC", "USDbC", "USDC.e", "USDT", "DAI"}


def topic_to_address(topic: str) -> str:
    return "0x" + topic[-40:].lower()


def address_to_topic(address: str) -> str:
    return "0x" + "0" * 24 + address.lower().replace("0x", "")


def decode_transfer_log(log: dict, decimals: int) -> Optional[TokenTransfer]:
    topics = log.get("topics") or []
    if len(topics) != 3 or topics[0].lower() != TRANSFER_TOPIC:
        return None  # ERC-721 transfers have 4 topics; skip them
    raw = int(log.get("data") or "0x0", 16)
    return TokenTransfer(
        token=log["address"].lower(),
        frm=topic_to_address(topics[1]),
        to=topic_to_address(topics[2]),
        amount=raw / (10 ** decimals),
        log_index=int(log.get("logIndex", "0x0"), 16) if isinstance(log.get("logIndex"), str) else int(log.get("logIndex") or 0),
    )


def base_value_usd(symbol: str, amount: float, eth_usd: Optional[float]) -> Optional[float]:
    if symbol in STABLES:
        return amount
    if symbol in ("WETH", "ETH"):
        return amount * eth_usd if eth_usd else None
    return None


def build_trades(
    *,
    chain: str,
    leader: str,
    tx_hash: str,
    block: int,
    ts: float,
    transfers: Iterable[TokenTransfer],
    base_assets: dict[str, str],
    eth_usd: Optional[float],
    native_sent: float = 0.0,
    native_received: float = 0.0,
) -> list[LeaderTrade]:
    """Classify one transaction initiated by `leader`.

    Received non-base token  -> BUY of that token.
    Sent non-base token      -> SELL of that token.
    Token-for-token swaps produce one SELL and one BUY.
    Base assets (WETH, stables, native ETH) paid/received give the USD value.
    """
    leader = leader.lower()
    net: dict[str, float] = defaultdict(float)
    for t in transfers:
        if t.to == leader:
            net[t.token] += t.amount
        if t.frm == leader:
            net[t.token] -= t.amount

    base_in_usd = 0.0
    base_out_usd = 0.0
    base_seen = False
    for token, amt in net.items():
        sym = base_assets.get(token)
        if sym is None or amt == 0:
            continue
        v = base_value_usd(sym, abs(amt), eth_usd)
        if v is None:
            continue
        base_seen = True
        if amt > 0:
            base_in_usd += v
        else:
            base_out_usd += v
    if native_sent and eth_usd:
        base_out_usd += native_sent * eth_usd
        base_seen = True
    if native_received and eth_usd:
        base_in_usd += native_received * eth_usd
        base_seen = True

    buys = {tok: amt for tok, amt in net.items() if tok not in base_assets and amt > 0}
    sells = {tok: -amt for tok, amt in net.items() if tok not in base_assets and amt < 0}

    trades: list[LeaderTrade] = []
    # Split quote value across tokens only in the simple 1-token case; otherwise leave unknown.
    for tok, amt in buys.items():
        quote = base_out_usd if (base_seen and len(buys) == 1 and not sells and base_out_usd > 0) else None
        trades.append(LeaderTrade(chain, leader, tx_hash, block, ts, "buy", tok, amt, quote))
    for tok, amt in sells.items():
        quote = base_in_usd if (base_seen and len(sells) == 1 and not buys and base_in_usd > 0) else None
        trades.append(LeaderTrade(chain, leader, tx_hash, block, ts, "sell", tok, amt, quote))
    return trades


def group_asset_transfers(rows: Iterable[dict], leader: str, decimals_lookup: Callable[[str], Optional[int]] | None = None):
    """Group alchemy_getAssetTransfers rows by tx hash.

    Returns {hash: {"block": int, "ts": float, "transfers": [TokenTransfer], "native_sent": float,
                    "leader_initiated": bool}}.
    Alchemy already scales `value` by decimals; rows with no value are skipped.
    """
    from datetime import datetime

    leader = leader.lower()
    out: dict[str, dict] = {}
    for r in rows:
        h = r["hash"]
        g = out.setdefault(h, {"block": int(r["blockNum"], 16), "ts": 0.0, "transfers": [],
                                "native_sent": 0.0, "leader_initiated": False})
        ts_str = (r.get("metadata") or {}).get("blockTimestamp")
        if ts_str:
            g["ts"] = datetime.fromisoformat(ts_str.replace("Z", "+00:00")).timestamp()
        value = r.get("value")
        frm = (r.get("from") or "").lower()
        to = (r.get("to") or "").lower()
        if value is None:
            continue
        if r.get("category") == "external":
            if frm == leader:
                g["native_sent"] += float(value)
                g["leader_initiated"] = True
            continue
        contract = ((r.get("rawContract") or {}).get("address") or "").lower()
        if not contract:
            continue
        if frm == leader:
            g["leader_initiated"] = True
        g["transfers"].append(TokenTransfer(contract, frm, to, float(value)))
    return out
