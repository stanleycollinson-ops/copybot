"""Market data: GeckoTerminal (prices, pools, OHLCV), GoPlus (token safety), CoinGecko (BTC/ETH/FX).

All free tiers. GeckoTerminal allows ~30 calls/min, so calls are rate-limited and cached.
"""
from __future__ import annotations

import logging
import statistics
import time
from datetime import datetime
from typing import Any, Optional

from .net import RateLimiter, TTLCache, get_json

log = logging.getLogger("market")

GT = "https://api.geckoterminal.com/api/v2"
GOPLUS = "https://api.gopluslabs.io/api/v1/token_security"
CG = "https://api.coingecko.com/api/v3"

_gt_limiter = RateLimiter(25, 60.0)
_bg_limiter = RateLimiter(12, 60.0)
_cg_limiter = RateLimiter(8, 60.0)
_gp_limiter = RateLimiter(20, 60.0)
_cache = TTLCache()


def _f(x: Any) -> Optional[float]:
    try:
        return float(x) if x not in (None, "") else None
    except (TypeError, ValueError):
        return None


def _b(x: Any) -> Optional[bool]:
    if x in (None, ""):
        return None
    return str(x) == "1"


class Market:
    def __init__(self, coingecko_key: str = "", gbp_fallback: float = 0.75, background: bool = False):
        self.cg_headers = {"x-cg-demo-api-key": coingecko_key} if coingecko_key else None
        self.gbp_fallback = gbp_fallback
        # Background jobs (discovery, scoring, replay) get their own slower budget so they can
        # never starve live signal checks of the shared GeckoTerminal allowance.
        self.background = background

    async def _gt(self, path: str, params: Optional[dict] = None) -> Any:
        if self.background:
            await _bg_limiter.wait()
        return await get_json(f"{GT}{path}", params=params, limiter=_gt_limiter)

    # ---------------- GeckoTerminal ----------------
    async def token_pool(self, network: str, token: str) -> Optional[dict]:
        """Deepest pool for a token, with price, liquidity, volume, momentum and age."""
        key = f"pool:{network}:{token}"
        hit = _cache.get(key)
        if hit is not None:
            return hit
        data = await self._gt(f"/networks/{network}/tokens/{token}/pools", {"page": 1})
        pools = (data or {}).get("data") or []
        if not pools:
            return None
        best = max(pools, key=lambda p: _f(p["attributes"].get("reserve_in_usd")) or 0)
        a = best["attributes"]
        rel = best.get("relationships", {})
        base_id = ((rel.get("base_token") or {}).get("data") or {}).get("id", "")
        token_is_base = base_id.lower().endswith(token.lower())
        price = _f(a.get("base_token_price_usd") if token_is_base else a.get("quote_token_price_usd"))
        created = a.get("pool_created_at")
        age_h = None
        if created:
            try:
                age_h = (time.time() - datetime.fromisoformat(created.replace("Z", "+00:00")).timestamp()) / 3600
            except ValueError:
                pass
        out = {
            "pool": a.get("address", "").lower(),
            "price_usd": price,
            "liquidity_usd": _f(a.get("reserve_in_usd")),
            "volume_24h_usd": _f((a.get("volume_usd") or {}).get("h24")),
            "price_change_h1": _f((a.get("price_change_percentage") or {}).get("h1")),
            "price_change_h24": _f((a.get("price_change_percentage") or {}).get("h24")),
            "age_h": age_h,
            "created_ts": time.time() - age_h * 3600 if age_h is not None else None,
            "token_is_base": token_is_base,
        }
        _cache.set(key, out, 45)
        return out

    async def token_prices(self, network: str, tokens: list[str]) -> dict[str, float]:
        """Batch current USD prices (up to 30 per call)."""
        out: dict[str, float] = {}
        for i in range(0, len(tokens), 30):
            chunk = tokens[i:i + 30]
            data = await self._gt(f"/simple/networks/{network}/token_price/{','.join(chunk)}")
            prices = (((data or {}).get("data") or {}).get("attributes") or {}).get("token_prices") or {}
            for k, v in prices.items():
                fv = _f(v)
                if fv:
                    out[k.lower()] = fv
        return out

    async def trending_pools(self, network: str, pages: int = 1) -> list[dict]:
        out: list[dict] = []
        for page in range(1, pages + 1):
            data = await self._gt(f"/networks/{network}/trending_pools", {"page": page})
            out += _parse_pools(data)
        return out

    async def top_volume_pools(self, network: str) -> list[dict]:
        data = await self._gt(f"/networks/{network}/pools", {"page": 1, "sort": "h24_volume_usd_desc"})
        return _parse_pools(data)

    async def pool_trades(self, network: str, pool: str, min_usd: float = 100) -> list[dict]:
        """Recent trades (up to ~300, last 24h) for a pool. Works for every DEX type because
        GeckoTerminal reports the wallet that sent each transaction."""
        data = await self._gt(f"/networks/{network}/pools/{pool}/trades",
                              {"trade_volume_in_usd_greater_than": min_usd})
        out = []
        for t in (data or {}).get("data") or []:
            a = t.get("attributes") or {}
            out.append({
                "wallet": (a.get("tx_from_address") or "").lower(),
                "to_token": (a.get("to_token_address") or "").lower(),
                "from_token": (a.get("from_token_address") or "").lower(),
                "price_to_usd": _f(a.get("price_to_in_usd")),
                "volume_usd": _f(a.get("volume_in_usd")),
                "tx": a.get("tx_hash"),
            })
        return out

    async def ohlcv_minute(self, network: str, pool: str, before_ts: float, limit: int = 200,
                           token_is_base: bool = True) -> list[tuple[float, float]]:
        """[(ts, close_usd)] ascending, minute candles ending at before_ts."""
        key = f"ohlcv:{network}:{pool}:{int(before_ts // 600)}:{limit}"
        hit = _cache.get(key)
        if hit is not None:
            return hit
        data = await self._gt(f"/networks/{network}/pools/{pool}/ohlcv/minute",
                              {"aggregate": 1, "before_timestamp": int(before_ts), "limit": limit,
                               "currency": "usd", "token": "base" if token_is_base else "quote"})
        rows = ((((data or {}).get("data") or {}).get("attributes") or {}).get("ohlcv_list")) or []
        out = sorted((float(r[0]), float(r[4])) for r in rows if r and r[4])
        _cache.set(key, out, 3600)
        return out

    # ---------------- GoPlus ----------------
    async def token_security(self, chain_id: int, token: str) -> dict:
        key = f"gp:{chain_id}:{token}"
        hit = _cache.get(key)
        if hit is not None:
            return hit
        data = await get_json(f"{GOPLUS}/{chain_id}", params={"contract_addresses": token}, limiter=_gp_limiter)
        res = ((data or {}).get("result") or {}).get(token.lower()) or {}
        if not res:
            return {}
        lp_locked = None
        if res.get("lp_holders"):
            lp_locked = sum((_f(h.get("percent")) or 0) for h in res["lp_holders"]
                            if str(h.get("is_locked")) == "1" or (h.get("address") or "").startswith("0x000000000000000000000000000000000000dead")) * 100
        top10 = None
        if res.get("holders"):
            # exclude contracts (pools, lockers) so we measure real wallet concentration
            wallets = [h for h in res["holders"] if str(h.get("is_contract")) != "1" and str(h.get("is_locked")) != "1"]
            top10 = sum((_f(h.get("percent")) or 0) for h in wallets[:10]) * 100
        out = {
            "is_honeypot": _b(res.get("is_honeypot")),
            "cannot_sell_all": _b(res.get("cannot_sell_all")),
            "buy_tax_pct": (_f(res.get("buy_tax")) or 0) * 100 if res.get("buy_tax") not in (None, "") else None,
            "sell_tax_pct": (_f(res.get("sell_tax")) or 0) * 100 if res.get("sell_tax") not in (None, "") else None,
            "is_open_source": _b(res.get("is_open_source")),
            "is_mintable": _b(res.get("is_mintable")),
            "owner_change_balance": _b(res.get("owner_change_balance")),
            "transfer_pausable": _b(res.get("transfer_pausable")),
            "slippage_modifiable": _b(res.get("slippage_modifiable")),
            "is_blacklisted": _b(res.get("is_blacklisted")),
            "hidden_owner": _b(res.get("hidden_owner")),
            "lp_locked_pct": lp_locked,
            "top10_holder_pct": top10,
        }
        _cache.set(key, out, 1800)
        return out

    # ---------------- CoinGecko ----------------
    async def btc_risk_on(self) -> Optional[bool]:
        """True if BTC daily close is above its 20-day average (simple regime filter)."""
        hit = _cache.get("btc_regime")
        if hit is not None:
            return hit
        data = await get_json(f"{CG}/coins/bitcoin/market_chart", params={"vs_currency": "usd", "days": 30,
                              "interval": "daily"}, headers=self.cg_headers, limiter=_cg_limiter)
        prices = [p[1] for p in (data or {}).get("prices", [])]
        if len(prices) < 21:
            return None
        res = prices[-1] > statistics.mean(prices[-21:-1])
        _cache.set("btc_regime", res, 3600)
        return res

    async def eth_usd(self) -> Optional[float]:
        hit = _cache.get("eth_usd")
        if hit is not None:
            return hit
        data = await get_json(f"{CG}/simple/price", params={"ids": "ethereum", "vs_currencies": "usd"},
                              headers=self.cg_headers, limiter=_cg_limiter)
        v = _f(((data or {}).get("ethereum") or {}).get("usd"))
        if v:
            _cache.set("eth_usd", v, 120)
        return v

    async def eth_usd_history(self, days: int = 90) -> list[tuple[float, float]]:
        hit = _cache.get(f"eth_hist:{days}")
        if hit is not None:
            return hit
        data = await get_json(f"{CG}/coins/ethereum/market_chart", params={"vs_currency": "usd", "days": days},
                              headers=self.cg_headers, limiter=_cg_limiter)
        out = [(p[0] / 1000, p[1]) for p in (data or {}).get("prices", [])]
        _cache.set(f"eth_hist:{days}", out, 3600)
        return out

    async def gbp_per_usd(self) -> float:
        hit = _cache.get("gbp")
        if hit is not None:
            return hit
        data = await get_json(f"{CG}/simple/price", params={"ids": "tether", "vs_currencies": "gbp"},
                              headers=self.cg_headers, limiter=_cg_limiter)
        v = _f(((data or {}).get("tether") or {}).get("gbp")) or self.gbp_fallback
        _cache.set("gbp", v, 3600)
        return v


def price_at(series: list[tuple[float, float]], ts: float) -> Optional[float]:
    """Nearest-at-or-after price in an ascending [(ts, price)] series (falls back to last before)."""
    if not series:
        return None
    for t, p in series:
        if t >= ts:
            return p
    return series[-1][1] if ts - series[-1][0] < 3600 else None


def _parse_pools(data: Any) -> list[dict]:
    out = []
    for p in (data or {}).get("data") or []:
        a = p["attributes"]
        base_id = ((p.get("relationships", {}).get("base_token") or {}).get("data") or {}).get("id", "")
        created = a.get("pool_created_at")
        created_ts = None
        if created:
            try:
                created_ts = datetime.fromisoformat(created.replace("Z", "+00:00")).timestamp()
            except ValueError:
                pass
        out.append({
            "pool": a.get("address", "").lower(),
            "token": base_id.split("_", 1)[-1].lower() if base_id else "",
            "name": a.get("name", ""),
            "liquidity_usd": _f(a.get("reserve_in_usd")),
            "price_change_h24": _f((a.get("price_change_percentage") or {}).get("h24")),
            "created_ts": created_ts,
        })
    return out
