"""Leader discovery and lifecycle: candidate -> probation (shadow) -> active -> retired."""
from __future__ import annotations

import logging
import statistics
import time
from collections import Counter

from .history import score_wallet

log = logging.getLogger("lifecycle")

IGNORE = {"0x0000000000000000000000000000000000000000", "0x000000000000000000000000000000000000dead"}


def pick_winners(pools: list[dict], base_assets: dict, dcfg: dict, now: float) -> list[dict]:
    seen, out = set(), []
    for p in pools:
        if p["pool"] in seen:
            continue
        seen.add(p["pool"])
        if (p["token"] and p["token"] not in base_assets
                and (p["price_change_h24"] or 0) >= dcfg["min_pump_pct_24h"]
                and (p["liquidity_usd"] or 0) >= dcfg["min_pool_liquidity_usd"]
                and p["created_ts"] and now - p["created_ts"] >= dcfg["min_pool_age_h"] * 3600):
            out.append(p)
    return sorted(out, key=lambda p: -(p["price_change_h24"] or 0))


def early_buyers(trades: list[dict], token: str, current_price: float, min_gain_pct: float,
                 max_trades_per_wallet: int = 10) -> set[str]:
    """Wallets that bought `token` at least `min_gain_pct` below today's price, i.e. before the move.
    Wallets trading the pool many times in a day are bots and are skipped."""
    activity = Counter(t["wallet"] for t in trades if t["wallet"])
    out = set()
    for t in trades:
        w = t["wallet"]
        if (not w or w in IGNORE or t["to_token"] != token or not t["price_to_usd"]
                or activity[w] > max_trades_per_wallet):
            continue
        if current_price >= t["price_to_usd"] * (1 + min_gain_pct / 100):
            out.add(w)
    return out


async def discover_candidates(engine, chain: str) -> list[str]:
    """Find wallets that bought today's winning tokens before they moved.

    Looks at trending and top-volume pools, keeps tokens up strongly over 24h with real
    liquidity (and older than a day, so not launch snipes), then reads each pool's recent
    trades for wallets that bought well below the current price. Wallets found across
    several winners rank first. Every candidate is then fully scored before use."""
    dcfg = engine.cfg["discovery"]
    ccfg = engine.cfg["chains"][chain]
    market = engine.bg_market
    net = ccfg["gecko_network"]
    pools = await market.trending_pools(net, pages=2) + await market.top_volume_pools(net)
    winners = pick_winners(pools, ccfg["base_assets"], dcfg, time.time())
    counts: Counter = Counter()
    for p in winners[: dcfg["max_winners"]]:
        info = await market.token_pool(net, p["token"])
        trades = await market.pool_trades(net, p["pool"], dcfg["min_trade_usd"])
        if info and info.get("price_usd"):
            counts.update(early_buyers(trades, p["token"], info["price_usd"], dcfg["min_gain_pct"]))
    known = {r["address"] for r in engine.db.q("SELECT address FROM leaders WHERE chain=?", (chain,))}
    ranked = [w for w, n in counts.most_common() if n >= dcfg["min_token_overlap"] and w not in known]
    log.info("%s discovery: %d pools checked, %d winners, %d new candidate wallets",
             chain, len(pools), len(winners), len(ranked))
    engine.db.kv_set(f"discovery_stats:{chain}", {"pools": len(pools), "winners": len(winners),
                                                    "candidates": len(ranked)})
    return ranked


async def evaluate_wallet(engine, chain: str, wallet: str, source: str) -> dict:
    m, trades = await score_wallet(engine.rpcs[chain], engine.bg_market, engine.cfg, chain, wallet)
    funder = await engine.rpcs[chain].first_funder(wallet)
    fields = dict(score=m.score, metrics=m.__dict__, funder=funder, median_trade_usd=m.median_trade_usd or None,
                  last_scored_ts=time.time())
    row = engine.db.leader(wallet, chain)
    if row is None:
        passed = not m.flags and m.score >= engine.cfg["lifecycle"]["promote_min_score"]
        # In paper mode no real money is at risk, so good candidates can trade (on paper) immediately.
        fast = engine.cfg["lifecycle"]["auto_activate_in_paper"] and not engine.cfg.is_live
        status = ("active" if fast else "probation") if passed else "retired"
        engine.db.upsert_leader(wallet, chain, source=source, status=status, **fields)
    else:
        engine.db.upsert_leader(wallet, chain, **fields)
    for t in trades[-200:]:
        engine.db.add_leader_trade(t)
    return {"score": m.score, "flags": m.flags, "metrics": m}


def shadow_performance(db, leader: str, chain: str, since: float) -> tuple[int, float | None]:
    """Mean 24h net return of this leader's APPROVED signals since `since` (shadow or real)."""
    rows = db.q("SELECT price_at_signal, price_24h, est_cost_pct FROM signals WHERE leader=? AND chain=? "
                "AND approved=1 AND ts>? AND price_24h IS NOT NULL AND price_at_signal>0", (leader, chain, since))
    rets = [(r["price_24h"] / r["price_at_signal"] - 1) * 100 - (r["est_cost_pct"] or 0) for r in rows]
    return len(rets), (statistics.mean(rets) if rets else None)


async def update_lifecycle(engine) -> list[str]:
    lc = engine.cfg["lifecycle"]
    db = engine.db
    now = time.time()
    notes: list[str] = []
    # probation -> active / retired
    for r in db.leaders(("probation",)):
        if now - (r["status_ts"] or now) < lc["probation_days"] * 86400:
            continue
        n, mean = shadow_performance(db, r["address"], r["chain"], r["status_ts"])
        name = r["label"] or r["address"][:10]
        if n >= lc["probation_min_signals"] and mean is not None and mean > 0 and (r["score"] or 0) >= lc["promote_min_score"]:
            db.upsert_leader(r["address"], r["chain"], status="active")
            notes.append(f"⬆️ {name} promoted to active ({n} shadow signals, avg {mean:+.1f}% after costs)")
        elif n < lc["probation_min_signals"] and not r["probation_extended"]:
            db.upsert_leader(r["address"], r["chain"], probation_extended=1, status_ts=now)
            notes.append(f"⏳ {name} probation extended (only {n} signals)")
        else:
            db.upsert_leader(r["address"], r["chain"], status="retired")
            notes.append(f"🗑 {name} retired after probation ({n} signals, avg {mean if mean is not None else 0:+.1f}%)")
    # active -> demoted / retired
    for r in db.leaders(("active",)):
        name = r["label"] or r["address"][:10]
        since = now - 30 * 86400
        basis = db.one("SELECT COALESCE(SUM(f.value_usd),0) v FROM fills f JOIN positions p ON p.id=f.position_id "
                       "WHERE p.leader=? AND p.chain=? AND f.side='buy' AND f.ts>?",
                       (r["address"], r["chain"], since))["v"]
        pnl = db.one("SELECT COALESCE(SUM(COALESCE(realised_pnl_usd,0) + CASE WHEN status='open' "
                     "THEN qty*COALESCE(last_price,entry_price) - cost_usd ELSE 0 END),0) v FROM positions "
                     "WHERE leader=? AND chain=? AND opened_ts>?", (r["address"], r["chain"], since))["v"]
        loss_pct = (-pnl / basis * 100) if basis > 0 else 0
        if loss_pct >= lc["demote_copy_loss_pct"] or (r["score"] or 0) < lc["demote_score"]:
            if r["demotions"] >= 1:
                db.upsert_leader(r["address"], r["chain"], status="retired")
                notes.append(f"🗑 {name} retired (second demotion; copy loss {loss_pct:.0f}%, score {r['score']:.0f})")
            else:
                db.upsert_leader(r["address"], r["chain"], status="probation", demotions=r["demotions"] + 1)
                notes.append(f"⬇️ {name} demoted to probation (copy loss {loss_pct:.0f}%, score {r['score']:.0f})")
    for n in notes:
        db.event("lifecycle", n)
    return notes


async def run_daily(engine) -> bool:
    lc = engine.cfg["lifecycle"]
    db = engine.db
    notes: list[str] = []
    now = time.time()
    # 1. rescore stale leaders
    for r in db.leaders(("probation", "active")):
        if now - (r["last_scored_ts"] or 0) > lc["rescore_interval_h"] * 3600:
            res = await evaluate_wallet(engine, r["chain"], r["address"], r["source"] or "manual")
            if res["flags"]:
                notes.append(f"⚠️ {r['label'] or r['address'][:10]} flagged on rescore: {', '.join(res['flags'])}")
    # 2. promotions / demotions
    notes += await update_lifecycle(engine)
    # 3. discovery when the pool is thin
    pipeline = len(db.leaders(("probation", "active")))
    if pipeline < lc["max_active_leaders"] + 5:
        budget = lc["max_candidates_scored_per_run"]
        for chain in engine.rpcs:
            cands = await discover_candidates(engine, chain)
            scored = passed = 0
            for wallet in cands[: budget // max(len(engine.rpcs), 1)]:
                res = await evaluate_wallet(engine, chain, wallet, "discovery")
                scored += 1
                if not res["flags"] and res["score"] >= lc["promote_min_score"]:
                    passed += 1
                    st = db.leader(wallet, chain)["status"]
                    notes.append(f"🆕 {wallet[:10]} on {chain} (score {res['score']:.0f}) added as {st}")
            st = db.kv_get(f"discovery_stats:{chain}", {})
            notes.append(f"🔎 {chain}: {st.get('pools', 0)} pools, {st.get('winners', 0)} winners, "
                         f"{len(cands)} candidates, {scored} scored, {passed} passed")
    active = len(db.leaders(("active",)))
    if active < lc["min_active_leaders"]:
        notes.append(f"ℹ️ only {active} active leaders (target {lc['min_active_leaders']}+); "
                     "add wallets you trust with `python -m bot.cli add-leader`")
    if notes:
        await engine.alerts.send("🔄 Daily leader review\n" + "\n".join(notes))
    return True
