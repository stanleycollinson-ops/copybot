"""Leader discovery and lifecycle: candidate -> probation (shadow) -> active -> retired."""
from __future__ import annotations

import logging
import statistics
import time
from collections import Counter

from .history import score_wallet

log = logging.getLogger("lifecycle")

IGNORE = {"0x0000000000000000000000000000000000000000", "0x000000000000000000000000000000000000dead"}


async def discover_candidates(engine, chain: str) -> list[str]:
    """Find wallets that bought trending tokens early-but-not-at-launch.

    Sniper bots buy in the first minutes; we skip those and look for wallets that bought
    while the pool was still young and later pumped. Wallets appearing across several
    winners rank highest."""
    dcfg = engine.cfg["discovery"]
    ccfg = engine.cfg["chains"][chain]
    rpc, market = engine.rpcs[chain], engine.bg_market
    pools = await market.trending_pools(ccfg["gecko_network"])
    now = time.time()
    winners = [p for p in pools
               if p["token"] and p["token"] not in ccfg["base_assets"]
               and (p["price_change_h24"] or 0) >= dcfg["min_pump_pct_24h"]
               and (p["liquidity_usd"] or 0) >= dcfg["min_pool_liquidity_usd"]
               and p["created_ts"] and now - p["created_ts"] >= dcfg["min_pool_age_h"] * 3600]
    counts: Counter = Counter()
    for p in winners[:8]:
        rows = await rpc.token_transfers(p["token"])
        snipe_until = p["created_ts"] + dcfg["sniper_window_min"] * 60
        buyers = set()
        from datetime import datetime
        for r in rows[: dcfg["buyers_per_token"]]:
            if (r.get("from") or "").lower() != p["pool"]:
                continue  # only tokens leaving the pool = buys
            ts_str = (r.get("metadata") or {}).get("blockTimestamp")
            ts = datetime.fromisoformat(ts_str.replace("Z", "+00:00")).timestamp() if ts_str else 0
            to = (r.get("to") or "").lower()
            if ts and ts < snipe_until or to in IGNORE or to == p["token"]:
                continue
            buyers.add(to)
        counts.update(buyers)
    known = {r["address"] for r in engine.db.q("SELECT address FROM leaders WHERE chain=?", (chain,))}
    ranked = [w for w, n in counts.most_common() if n >= dcfg["min_token_overlap"] and w not in known]
    log.info("%s discovery: %d trending winners, %d new candidate wallets", chain, len(winners), len(ranked))
    return ranked


async def evaluate_wallet(engine, chain: str, wallet: str, source: str) -> dict:
    m, trades = await score_wallet(engine.rpcs[chain], engine.bg_market, engine.cfg, chain, wallet)
    funder = await engine.rpcs[chain].first_funder(wallet)
    fields = dict(score=m.score, metrics=m.__dict__, funder=funder, median_trade_usd=m.median_trade_usd or None,
                  last_scored_ts=time.time())
    row = engine.db.leader(wallet, chain)
    if row is None:
        status = "probation" if (not m.flags and m.score >= engine.cfg["lifecycle"]["promote_min_score"]) else "retired"
        engine.db.upsert_leader(wallet, chain, source=source, status=status, **fields)
    else:
        engine.db.upsert_leader(wallet, chain, **fields)
    for t in trades[-200:]:
        engine.db.add_leader_trade(t)
    return {"score": m.score, "flags": m.flags, "metrics": m}


def shadow_performance(db, leader: str, chain: str, since: float) -> tuple[int, float | None]:
    """Mean 24h net return of this leader's APPROVED signals since `since` (shadow or real)."""
    rows = db.q("SELECT price_at_signal, price_24h, est_cost_pct FROM signals WHERE leader=? AND chain=? "
                "AND approved=1 AND ts>? AND price_24h IS NOT NULL AND price_at_signal>0", (leader, chain, since))
    rets = [(r["price_24h"] / r["price_at_signal"] - 1) * 100 - (r["est_cost_pct"] or 0) for r in rows]
    return len(rets), (statistics.mean(rets) if rets else None)


async def update_lifecycle(engine) -> list[str]:
    lc = engine.cfg["lifecycle"]
    db = engine.db
    now = time.time()
    notes: list[str] = []
    # probation -> active / retired
    for r in db.leaders(("probation",)):
        if now - (r["status_ts"] or now) < lc["probation_days"] * 86400:
            continue
        n, mean = shadow_performance(db, r["address"], r["chain"], r["status_ts"])
        name = r["label"] or r["address"][:10]
        if n >= lc["probation_min_signals"] and mean is not None and mean > 0 and (r["score"] or 0) >= lc["promote_min_score"]:
            db.upsert_leader(r["address"], r["chain"], status="active")
            notes.append(f"⬆️ {name} promoted to active ({n} shadow signals, avg {mean:+.1f}% after costs)")
        elif n < lc["probation_min_signals"] and not r["probation_extended"]:
            db.upsert_leader(r["address"], r["chain"], probation_extended=1, status_ts=now)
            notes.append(f"⏳ {name} probation extended (only {n} signals)")
        else:
            db.upsert_leader(r["address"], r["chain"], status="retired")
            notes.append(f"🗑 {name} retired after probation ({n} signals, avg {mean if mean is not None else 0:+.1f}%)")
    # active -> demoted / retired
    for r in db.leaders(("active",)):
        name = r["label"] or r["address"][:10]
        since = now - 30 * 86400
        basis = db.one("SELECT COALESCE(SUM(f.value_usd),0) v FROM fills f JOIN positions p ON p.id=f.position_id "
                       "WHERE p.leader=? AND p.chain=? AND f.side='buy' AND f.ts>?",
                       (r["address"], r["chain"], since))["v"]
        pnl = db.one("SELECT COALESCE(SUM(COALESCE(realised_pnl_usd,0) + CASE WHEN status='open' "
                     "THEN qty*COALESCE(last_price,entry_price) - cost_usd ELSE 0 END),0) v FROM positions "
                     "WHERE leader=? AND chain=? AND opened_ts>?", (r["address"], r["chain"], since))["v"]
        loss_pct = (-pnl / basis * 100) if basis > 0 else 0
        if loss_pct >= lc["demote_copy_loss_pct"] or (r["score"] or 0) < lc["demote_score"]:
            if r["demotions"] >= 1:
                db.upsert_leader(r["address"], r["chain"], status="retired")
                notes.append(f"🗑 {name} retired (second demotion; copy loss {loss_pct:.0f}%, score {r['score']:.0f})")
            else:
                db.upsert_leader(r["address"], r["chain"], status="probation", demotions=r["demotions"] + 1)
                notes.append(f"⬇️ {name} demoted to probation (copy loss {loss_pct:.0f}%, score {r['score']:.0f})")
    for n in notes:
        db.event("lifecycle", n)
    return notes


async def run_daily(engine) -> bool:
    lc = engine.cfg["lifecycle"]
    db = engine.db
    notes: list[str] = []
    now = time.time()
    # 1. rescore stale leaders
    for r in db.leaders(("probation", "active")):
        if now - (r["last_scored_ts"] or 0) > lc["rescore_interval_h"] * 3600:
            res = await evaluate_wallet(engine, r["chain"], r["address"], r["source"] or "manual")
            if res["flags"]:
                notes.append(f"⚠️ {r['label'] or r['address'][:10]} flagged on rescore: {', '.join(res['flags'])}")
    # 2. promotions / demotions
    notes += await update_lifecycle(engine)
    # 3. discovery when the pool is thin
    pipeline = len(db.leaders(("probation", "active")))
    if pipeline < lc["max_active_leaders"] + 5:
        budget = lc["max_candidates_scored_per_run"]
        for chain in engine.rpcs:
            for wallet in (await discover_candidates(engine, chain))[: budget // max(len(engine.rpcs), 1)]:
                res = await evaluate_wallet(engine, chain, wallet, "discovery")
                if not res["flags"] and res["score"] >= lc["promote_min_score"]:
                    notes.append(f"🆕 new candidate {wallet[:10]} on {chain} (score {res['score']:.0f}), on probation")
    active = len(db.leaders(("active",)))
    if active < lc["min_active_leaders"]:
        notes.append(f"ℹ️ only {active} active leaders (target {lc['min_active_leaders']}+); "
                     "add wallets you trust with `python -m bot.cli add-leader`")
    if notes:
        await engine.alerts.send("🔄 Daily leader review\n" + "\n".join(notes))
    return True
