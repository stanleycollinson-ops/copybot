"""Command line: python -m bot.cli <command>

  run                         start the bot (paper mode unless config says otherwise)
  check                       test your API keys and data sources
  add-leader ADDR CHAIN [-l LABEL] [--activate]
                              score a wallet and add it (probation unless --activate)
  score ADDR CHAIN            score a wallet without adding it
  replay ADDR CHAIN [--delay 30]
                              backtest copying a wallet's recent trades
  discover [CHAIN]            run leader discovery now
  leaders                     list leaders
  report                      performance so far + go-live checklist
  proposals | trial ID | promote ID | reject ID
                              strategy-improvement workflow
  export-tax [--mode live|paper]
                              write HMRC-ready CSVs to data/tax/
  kill | resume               emergency stop for new trades / undo it
  close-all                   (paper) close every open position at market
"""
from __future__ import annotations

import argparse
import asyncio
import json
import logging
import sys

from .config import load_config
from .db import DB


def _setup(args):
    logging.basicConfig(level=logging.DEBUG if getattr(args, "verbose", False) else logging.INFO,
                        format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    cfg = load_config(args.config)
    db = DB(cfg.data_dir / "copybot.sqlite")
    return cfg, db


def _engine(cfg, db):
    from .engine import Engine
    return Engine(cfg, db)


def _print_metrics(m) -> None:
    print(f"  score            {m.score:.0f}/100")
    print(f"  trades (closed)  {m.n_trades} ({m.n_closed})")
    print(f"  realised P&L     ${m.realised_pnl_usd:,.0f} (last 30d ${m.pnl_30d_usd:,.0f})")
    print(f"  win rate         {m.win_rate * 100:.0f}%   profit factor {m.profit_factor:.2f}")
    print(f"  max drawdown     ${m.max_drawdown_usd:,.0f}")
    print(f"  trades/day       {m.trades_per_day:.1f}   median hold {m.median_hold_s / 3600:.1f}h")
    print(f"  median buy size  ${m.median_trade_usd:,.0f}")
    if m.copy_return_pct is not None:
        print(f"  copy return      {m.copy_return_pct:+.1f}% avg per trade after costs ({m.copy_n} replayed)")
    print(f"  flags            {', '.join(m.flags) or 'none'}")


async def _score(cfg, db, addr, chain, add=False, label="", activate=False):
    from .lifecycle import evaluate_wallet

    eng = _engine(cfg, db)
    if add:
        db.upsert_leader(addr, chain, label=label, source="manual", status="probation")
    res = await evaluate_wallet(eng, chain, addr.lower(), "manual")
    _print_metrics(res["metrics"])
    if add:
        if activate:
            db.upsert_leader(addr, chain, status="active")
            print("Added as ACTIVE (skips probation; only do this for wallets you've verified yourself).")
        elif res["flags"]:
            print("Added on probation, but it's flagged: it will most likely be retired at review.")
        else:
            print("Added on probation: its signals are tracked in shadow mode until it proves itself.")


async def _replay(cfg, db, addr, chain, delay):
    from .history import fetch_trades, replay

    eng = _engine(cfg, db)
    ccfg = cfg["chains"][chain]
    trades = await fetch_trades(eng.rpcs[chain], eng.bg_market, ccfg, chain, addr, cfg["scoring"]["history_days"])
    size = cfg["capital_gbp"] / cfg["gbp_per_usd_fallback"] * cfg["risk"]["max_trade_pct"] / 100
    res = await replay(eng.bg_market, ccfg["gecko_network"], trades, delay_s=delay, size_usd=size,
                       dex_fee_pct=cfg["validation"]["dex_fee_pct"], gas_usd=ccfg["gas_usd_per_swap"],
                       max_trades=cfg["scoring"]["replay_trades"])
    print(f"{'token':<44} {'exit':<11} {'leader %':>9} {'copy % (net)':>13}")
    for r in res:
        lr = f"{r.leader_return_pct:+.1f}" if r.leader_return_pct is not None else "–"
        cr = f"{r.copy_return_pct:+.1f}" if r.copy_return_pct is not None else "–"
        print(f"{r.token:<44} {r.exit_kind:<11} {lr:>9} {cr:>13}")
    rets = [r.copy_return_pct for r in res if r.copy_return_pct is not None]
    if rets:
        print(f"\nAverage copy return {sum(rets) / len(rets):+.2f}% per trade over {len(rets)} trades "
              f"(delay {delay:.0f}s, ${size:.0f} trades, fees+slippage+gas included)")


async def _check(cfg, db):
    eng = _engine(cfg, db)
    ok = True
    for name, rpc in eng.rpcs.items():
        bn = await rpc.call("eth_blockNumber", [])
        print(f"[{'ok' if bn else 'FAIL'}] Alchemy {name}: block {int(bn, 16) if bn else '-'}")
        ok &= bool(bn)
    pool = await eng.market.token_pool("base", cfg["chains"]["base"]["wrapped_native"])
    print(f"[{'ok' if pool else 'FAIL'}] GeckoTerminal: WETH ${pool['price_usd'] if pool else '-'}")
    sec = await eng.market.token_security(8453, "0x833589fcd6edb6e08f4c7c32d4f71b54bda02913")
    print(f"[{'ok' if sec else 'FAIL'}] GoPlus token security")
    btc = await eng.market.btc_risk_on()
    print(f"[{'ok' if btc is not None else 'FAIL'}] CoinGecko BTC regime: {'risk-on' if btc else 'risk-off'}")
    print(f"[{'ok' if eng.alerts.enabled else 'off'}] Telegram alerts")
    if eng.alerts.enabled:
        await eng.alerts.send("👋 CopyBot test message: alerts are working")
    print(f"Mode: {'LIVE' if cfg.is_live else 'PAPER'}")
    return ok


def main(argv=None):
    ap = argparse.ArgumentParser(prog="bot.cli", description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--config", default="config.yaml")
    ap.add_argument("-v", "--verbose", action="store_true")
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("run")
    sub.add_parser("check")
    a = sub.add_parser("add-leader")
    a.add_argument("address")
    a.add_argument("chain")
    a.add_argument("-l", "--label", default="")
    a.add_argument("--activate", action="store_true")
    s = sub.add_parser("score")
    s.add_argument("address")
    s.add_argument("chain")
    r = sub.add_parser("replay")
    r.add_argument("address")
    r.add_argument("chain")
    r.add_argument("--delay", type=float, default=30)
    d = sub.add_parser("discover")
    d.add_argument("chain", nargs="?")
    sub.add_parser("leaders")
    sub.add_parser("report")
    sub.add_parser("proposals")
    for name in ("trial", "promote", "reject"):
        p = sub.add_parser(name)
        p.add_argument("id", type=int)
        if name == "promote":
            p.add_argument("--force", action="store_true")
    t = sub.add_parser("export-tax")
    t.add_argument("--mode", default="live", choices=["live", "paper"])
    sub.add_parser("kill")
    sub.add_parser("resume")
    sub.add_parser("close-all")
    args = ap.parse_args(argv)
    cfg, db = _setup(args)

    if args.cmd == "run":
        try:
            asyncio.run(_engine(cfg, db).run())
        except KeyboardInterrupt:
            print("stopped")
    elif args.cmd == "check":
        sys.exit(0 if asyncio.run(_check(cfg, db)) else 1)
    elif args.cmd == "add-leader":
        asyncio.run(_score(cfg, db, args.address, args.chain, add=True, label=args.label, activate=args.activate))
    elif args.cmd == "score":
        asyncio.run(_score(cfg, db, args.address, args.chain))
    elif args.cmd == "replay":
        asyncio.run(_replay(cfg, db, args.address, args.chain, args.delay))
    elif args.cmd == "discover":
        async def _disc():
            from .lifecycle import discover_candidates, evaluate_wallet
            eng = _engine(cfg, db)
            for chain in [args.chain] if args.chain else list(eng.rpcs):
                cands = await discover_candidates(eng, chain)
                print(f"{chain}: {len(cands)} candidates; scoring the first {cfg['lifecycle']['max_candidates_scored_per_run']}")
                for w in cands[: cfg["lifecycle"]["max_candidates_scored_per_run"]]:
                    res = await evaluate_wallet(eng, chain, w, "discovery")
                    print(f"  {w} score {res['score']:.0f} {'; '.join(res['flags']) or 'OK -> probation'}")
        asyncio.run(_disc())
    elif args.cmd == "leaders":
        for r in db.q("SELECT * FROM leaders ORDER BY status, score DESC"):
            flags = ", ".join((json.loads(r["metrics"]) if r["metrics"] else {}).get("flags", []))
            print(f"{r['status']:<10} {r['score'] or 0:>5.0f}  {r['chain']:<9} {r['address']}  {r['label'] or ''}  {flags}")
    elif args.cmd == "report":
        from .report import go_live_check, performance
        p = performance(db, "paper")
        for k, v in p.items():
            print(f"{k:<26} {v if not isinstance(v, float) else round(v, 3)}")
        print("\nGo-live checklist:")
        for ok, line in go_live_check(db):
            print(f"  [{'x' if ok else ' '}] {line}")
    elif args.cmd == "proposals":
        from .improve import trial_status
        for r in db.q("SELECT * FROM proposals ORDER BY id DESC"):
            print(f"#{r['id']} {r['status']:<9} {r['param']}: {r['current_value']} -> {r['proposed_value']} "
                  f"(train {r['train_baseline']:+.0f}->{r['train_metric']:+.0f}, test {r['test_baseline']:+.0f}->{r['test_metric']:+.0f})")
            if r["status"] == "trial":
                print("   ", trial_status(db, r, cfg["improvement"]["trial_days"]))
    elif args.cmd == "trial":
        from .improve import start_trial
        print(start_trial(db, args.id))
    elif args.cmd == "promote":
        from .improve import promote
        print(promote(db, args.id, cfg["improvement"]["trial_days"], args.force))
    elif args.cmd == "reject":
        from .improve import reject
        print(reject(db, args.id))
    elif args.cmd == "export-tax":
        from .tax import export
        ledger, cgt, totals = export(db, cfg.data_dir / "tax", args.mode)
        print(f"Wrote {ledger}\nWrote {cgt}")
        for year, gain in sorted(totals.items()):
            print(f"  tax year {year}: net gain £{gain:,.2f} (estimate; check against the annual exempt amount)")
    elif args.cmd == "kill":
        db.kv_set("kill", True)
        (cfg.data_dir / "KILL").touch()
        print("Kill switch ON: no new trades. Open positions are still managed (stop-loss etc).")
    elif args.cmd == "resume":
        db.kv_set("kill", False)
        (cfg.data_dir / "KILL").unlink(missing_ok=True)
        print("Kill switch OFF.")
    elif args.cmd == "close-all":
        async def _close():
            eng = _engine(cfg, db)
            rows = db.q("SELECT * FROM positions WHERE status='open' AND mode='paper'")
            await eng.close_positions(rows, 1.0, "manual close-all")
            print(f"Closed {len(rows)} positions.")
        asyncio.run(_close())


if __name__ == "__main__":
    main()
