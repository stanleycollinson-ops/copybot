"""Execution. PaperExecutor simulates fills with realistic fees, price impact and gas.

LiveExecutor is intentionally not implemented yet: it is built only after the paper-trading
period proves the strategy is profitable after costs (see README go-live checklist).
"""
from __future__ import annotations

import logging
import time
from typing import Optional

log = logging.getLogger("exec")


def impact_pct(size_usd: float, liquidity_usd: Optional[float]) -> float:
    return (2 * size_usd / liquidity_usd * 100) if liquidity_usd else 2.0


class PaperExecutor:
    mode = "paper"

    def __init__(self, db, dex_fee_pct: float, starting_cash_usd: float):
        self.db = db
        self.fee = dex_fee_pct
        if self.db.kv_get("cash_usd") is None:
            self.db.kv_set("cash_usd", starting_cash_usd)
            self.db.kv_set("starting_cash_usd", starting_cash_usd)

    @property
    def cash(self) -> float:
        return float(self.db.kv_get("cash_usd", 0.0))

    def _set_cash(self, v: float) -> None:
        self.db.kv_set("cash_usd", v)

    def buy(self, *, chain: str, token: str, symbol: str, leader: str, signal_id: int, size_usd: float,
            price: float, liquidity_usd: Optional[float], gas_usd: float, leader_price: Optional[float],
            delay_s: float, gbp_per_usd: float) -> int:
        slip = impact_pct(size_usd, liquidity_usd) + self.fee
        fill_px = price * (1 + slip / 100)
        qty = size_usd / fill_px
        now = time.time()
        pid = self.db.ex(
            "INSERT INTO positions(chain,token,symbol,leader,signal_id,mode,status,qty,cost_usd,entry_price,"
            "leader_price,opened_ts,last_price,delay_s,fees_usd) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (chain, token, symbol, leader, signal_id, self.mode, "open", qty, size_usd + gas_usd, fill_px,
             leader_price, now, price, delay_s, gas_usd + size_usd * self.fee / 100))
        self.db.ex("INSERT INTO fills(ts,position_id,chain,token,symbol,side,qty,price_usd,value_usd,fee_usd,"
                   "gbp_per_usd,mode,tx_hash) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",
                   (now, pid, chain, token, symbol, "buy", qty, fill_px, size_usd, gas_usd, gbp_per_usd, self.mode, None))
        self._set_cash(self.cash - size_usd - gas_usd)
        return pid

    def sell(self, *, position_id: int, fraction: float, price: float, liquidity_usd: Optional[float],
             gas_usd: float, reason: str, gbp_per_usd: float) -> float:
        p = self.db.one("SELECT * FROM positions WHERE id=?", (position_id,))
        if not p or p["status"] != "open":
            return 0.0
        fraction = max(0.0, min(fraction, 1.0))
        qty = p["qty"] * fraction
        gross = qty * price
        slip = impact_pct(gross, liquidity_usd) + self.fee
        fill_px = price * (1 - slip / 100)
        proceeds = qty * fill_px - gas_usd
        cost_part = p["cost_usd"] * fraction
        now = time.time()
        self.db.ex("INSERT INTO fills(ts,position_id,chain,token,symbol,side,qty,price_usd,value_usd,fee_usd,"
                   "gbp_per_usd,mode,tx_hash) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",
                   (now, position_id, p["chain"], p["token"], p["symbol"], "sell", qty, fill_px, qty * fill_px,
                    gas_usd, gbp_per_usd, self.mode, None))
        fees = (p["fees_usd"] or 0) + gas_usd + gross * self.fee / 100
        if fraction >= 0.999:
            self.db.ex("UPDATE positions SET status='closed', closed_ts=?, exit_price=?, "
                       "proceeds_usd=COALESCE(proceeds_usd,0)+?, realised_pnl_usd=COALESCE(realised_pnl_usd,0)+?, "
                       "exit_reason=?, qty=0, cost_usd=0, last_price=?, fees_usd=? WHERE id=?",
                       (now, fill_px, proceeds, proceeds - cost_part, reason, price, fees, position_id))
        else:
            self.db.ex("UPDATE positions SET qty=qty-?, cost_usd=cost_usd-?, proceeds_usd=COALESCE(proceeds_usd,0)+?, "
                       "realised_pnl_usd=COALESCE(realised_pnl_usd,0)+?, last_price=?, fees_usd=? WHERE id=?",
                       (qty, cost_part, proceeds, proceeds - cost_part, price, fees, position_id))
        self._set_cash(self.cash + proceeds)
        return proceeds - cost_part


class LiveExecutor:  # pragma: no cover - deliberately disabled
    mode = "live"

    def __init__(self, *_, **__):
        raise SystemExit(
            "Live execution is not enabled in this version. Run paper mode for 2-4 weeks first; "
            "if `python -m bot.cli report` shows positive results after costs, ask for the live "
            "execution module (DEX aggregator swaps with simulation, exact approvals and min-out protection).")
