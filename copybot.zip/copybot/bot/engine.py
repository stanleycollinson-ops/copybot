"""The running bot: watch leaders, validate signals, size and execute, manage positions, run jobs."""
from __future__ import annotations

import asyncio
import json
import logging
import statistics
import time
from collections import OrderedDict
from datetime import datetime, timezone
from typing import Optional

from .alerts import Alerts
from .config import Config
from .db import DB
from .executor import LiveExecutor, PaperExecutor
from .market import Market
from .models import LeaderTrade, Snapshot
from .parse import TRANSFER_TOPIC, build_trades, decode_transfer_log
from .risk import Exposure, RiskGuard, size_trade
from .rpc import ChainRPC
from .validator import validate

log = logging.getLogger("engine")


class Engine:
    def __init__(self, cfg: Config, db: DB):
        self.base_cfg = cfg
        self.db = db
        self.cfg = cfg.with_overrides(db.overrides())
        self.market = Market(cfg.secrets.coingecko_api_key, cfg["gbp_per_usd_fallback"])
        self.bg_market = Market(cfg.secrets.coingecko_api_key, cfg["gbp_per_usd_fallback"], background=True)
        self.rpcs = {name: ChainRPC(name, c["alchemy_slug"], cfg.secrets.alchemy_api_key)
                     for name, c in cfg.enabled_chains().items()}
        self.alerts = Alerts(cfg.secrets.telegram_bot_token, cfg.secrets.telegram_chat_id,
                             cfg["alerts"]["telegram_enabled"])
        self.guard = RiskGuard(db, self.cfg["risk"], cfg.data_dir)
        start_usd = cfg["capital_gbp"] / cfg["gbp_per_usd_fallback"]
        self.executor = LiveExecutor() if cfg.is_live else PaperExecutor(db, self.cfg["validation"]["dex_fee_pct"], start_usd)
        self.queue: asyncio.Queue[LeaderTrade] = asyncio.Queue()
        self.seen: OrderedDict[str, None] = OrderedDict()
        self.leader_version = 0
        self.pause_reason: Optional[str] = None

    # ------------------------------------------------------------------ leaders
    def seed_leaders(self) -> None:
        for l in self.cfg["leaders"]:
            if self.db.leader(l["address"], l["chain"]) is None:
                # seeds start on probation: they must prove themselves in shadow mode first
                self.db.upsert_leader(l["address"], l["chain"], label=l.get("label", ""), source="seed",
                                      status="probation")

    def watched(self, chain: str) -> set[str]:
        return {r["address"] for r in self.db.leaders(("probation", "active")) if r["chain"] == chain}

    def bump_leaders(self) -> None:
        self.leader_version += 1

    # ------------------------------------------------------------------ watcher
    async def watch_chain(self, chain: str) -> None:
        rpc = self.rpcs[chain]
        while True:
            leaders = sorted(self.watched(chain))
            if not leaders:
                await asyncio.sleep(60)
                continue
            version = self.leader_version
            task = asyncio.create_task(self._consume(chain, rpc, leaders))
            while not task.done() and version == self.leader_version and set(leaders) == self.watched(chain):
                await asyncio.sleep(30)
            task.cancel()
            try:
                await task
            except (asyncio.CancelledError, Exception):
                pass

    async def _consume(self, chain: str, rpc: ChainRPC, leaders: list[str]) -> None:
        async for lg in rpc.subscribe_transfer_logs(leaders):
            h = lg.get("transactionHash")
            if not h or h in self.seen:
                continue
            self.seen[h] = None
            if len(self.seen) > 5000:
                self.seen.popitem(last=False)
            asyncio.create_task(self._handle_tx(chain, rpc, h))

    async def _handle_tx(self, chain: str, rpc: ChainRPC, tx_hash: str) -> None:
        try:
            await asyncio.sleep(1.0)  # let the node index the full receipt
            tx = await rpc.call("eth_getTransactionByHash", [tx_hash])
            if not tx:
                return
            leader = (tx.get("from") or "").lower()
            if leader not in self.watched(chain):
                return  # not initiated by a leader (airdrop/spam/someone paying them)
            receipt = await rpc.call("eth_getTransactionReceipt", [tx_hash])
            if not receipt or receipt.get("status") != "0x1":
                return
            transfers = []
            for lg in receipt.get("logs", []):
                topics = lg.get("topics") or []
                if len(topics) != 3 or topics[0].lower() != TRANSFER_TOPIC:
                    continue
                dec = await rpc.decimals(lg["address"].lower())
                if dec is None:
                    continue
                t = decode_transfer_log(lg, dec)
                if t and (t.frm == leader or t.to == leader):
                    transfers.append(t)
            ccfg = self.cfg["chains"][chain]
            base = ccfg["base_assets"]
            native_sent = int(tx.get("value", "0x0"), 16) / 1e18
            sells = [t for t in transfers if t.frm == leader and t.token not in base]
            got_base = any(t.to == leader and t.token in base for t in transfers)
            native_received = await rpc.native_received_in_tx(leader, receipt) if sells and not got_base else 0.0
            block = int(receipt["blockNumber"], 16)
            ts = await rpc.block_ts(block) or time.time()
            eth_usd = await self.market.eth_usd()
            for trade in build_trades(chain=chain, leader=leader, tx_hash=tx_hash, block=block, ts=ts,
                                      transfers=transfers, base_assets=base, eth_usd=eth_usd,
                                      native_sent=native_sent, native_received=native_received):
                if self.db.add_leader_trade(trade):
                    await self.queue.put(trade)
        except Exception:
            log.exception("failed to process tx %s on %s", tx_hash, chain)

    # ------------------------------------------------------------------ portfolio
    def exposure(self) -> Exposure:
        cash = self.executor.cash
        by_asset: dict[str, float] = {}
        by_leader: dict[str, float] = {}
        by_chain: dict[str, float] = {}
        rows = self.db.q("SELECT * FROM positions WHERE status='open' AND mode=?", (self.executor.mode,))
        total = 0.0
        for p in rows:
            v = p["qty"] * (p["last_price"] or p["entry_price"])
            total += v
            by_asset[f"{p['chain']}:{p['token']}"] = by_asset.get(f"{p['chain']}:{p['token']}", 0) + v
            by_leader[p["leader"]] = by_leader.get(p["leader"], 0) + v
            by_chain[p["chain"]] = by_chain.get(p["chain"], 0) + v
        return Exposure(cash + total, cash, len(rows), by_asset, by_leader, by_chain)

    def leader_weight(self, score: float) -> float:
        scores = [r["score"] for r in self.db.leaders(("active",)) if r["score"]]
        avg = statistics.mean(scores) if scores else 60.0
        return score / avg if avg else 1.0

    # ------------------------------------------------------------------ signals
    async def process_signals(self) -> None:
        while True:
            t = await self.queue.get()
            try:
                if t.side == "buy":
                    await self.handle_buy(t)
                else:
                    await self.handle_leader_sell(t)
            except Exception:
                log.exception("signal processing failed for %s", t)

    async def build_snapshot(self, t: LeaderTrade, leader_row, trade_size_usd: float) -> Snapshot:
        ccfg = self.cfg["chains"][t.chain]
        pool = await self.market.token_pool(ccfg["gecko_network"], t.token) or {}
        sec = await self.market.token_security(ccfg["chain_id"], t.token)
        btc = await self.market.btc_risk_on()
        median = leader_row["median_trade_usd"]
        if not median:
            vals = [r["quote_usd"] for r in self.db.q(
                "SELECT quote_usd FROM leader_trades WHERE leader=? AND side='buy' AND quote_usd>0 AND ts>?",
                (t.leader, time.time() - 90 * 86400))]
            median = statistics.median(vals) if len(vals) >= 3 else None
        niche = True
        if median and t.quote_usd:
            niche = 0.25 * median <= t.quote_usd <= 5 * median
        recent_sells = self.db.one(
            "SELECT COUNT(DISTINCT token) n FROM leader_trades WHERE leader=? AND side='sell' AND ts>?",
            (t.leader, time.time() - 3600))["n"]
        window = self.cfg["validation"]["consensus_window_min"] * 60
        buyers = [r["leader"] for r in self.db.q(
            "SELECT DISTINCT leader FROM leader_trades WHERE chain=? AND token=? AND side='buy' AND ts>?",
            (t.chain, t.token, time.time() - window))]
        groups = set()
        for b in buyers:
            row = self.db.leader(b, t.chain)
            if row and row["status"] in ("probation", "active"):
                groups.add(row["funder"] or b)  # wallets funded from the same source count once
        rpc = self.rpcs[t.chain]
        return Snapshot(
            chain=t.chain, token=t.token, symbol=await rpc.symbol(t.token), leader=t.leader,
            leader_status=leader_row["status"], leader_score=leader_row["score"] or 50.0,
            leader_median_trade_usd=median, leader_trade_usd=t.quote_usd, leader_niche_match=niche,
            leader_recent_sells_1h=recent_sells, leader_price=t.price_usd, delay_s=max(0.0, time.time() - t.ts),
            current_price=pool.get("price_usd"), liquidity_usd=pool.get("liquidity_usd"),
            volume_24h_usd=pool.get("volume_24h_usd"), price_change_h1=pool.get("price_change_h1"),
            price_change_h24=pool.get("price_change_h24"), token_age_h=pool.get("age_h"),
            btc_risk_on=btc, consensus_independent=max(len(groups), 1), trade_size_usd=trade_size_usd,
            gas_usd_per_swap=ccfg["gas_usd_per_swap"], **sec)

    async def handle_buy(self, t: LeaderTrade) -> None:
        leader = self.db.leader(t.leader, t.chain)
        if leader is None or leader["status"] not in ("probation", "active"):
            return
        exp = self.exposure()
        provisional = exp.equity_usd * self.cfg["risk"]["max_trade_pct"] / 100
        snap = await self.build_snapshot(t, leader, provisional)
        vcfg = self.cfg["validation"]
        dec = validate(snap, vcfg)

        # proposals on trial are evaluated side by side, never traded
        trial = self.db.one("SELECT * FROM proposals WHERE status='trial' ORDER BY id DESC LIMIT 1")
        trial_ok = None
        if trial:
            tcfg = self.cfg.with_overrides({trial["param"]: json.loads(trial["proposed_value"])})
            trial_ok = int(validate(snap, tcfg["validation"]).approved)

        executable = leader["status"] == "active"
        mode = self.executor.mode if executable else "shadow"
        sid = self.db.add_signal(ts=time.time(), chain=t.chain, leader=t.leader, token=t.token, symbol=snap.symbol,
                                 side="buy", tx_hash=t.tx_hash, mode=mode, approved=int(dec.approved),
                                 score=dec.score, reasons=dec.reasons, components=dec.components,
                                 est_cost_pct=dec.est_cost_pct, snapshot=snap.to_dict(),
                                 price_at_signal=snap.current_price, trial_approved=trial_ok,
                                 trial_proposal_id=trial["id"] if trial else None)
        tag = f"{snap.symbol} on {t.chain} from {leader['label'] or t.leader[:10]}"
        if not dec.approved:
            line = f"⛔ {tag}: {dec.summary}"
            if executable and dec.score >= self.cfg["alerts"]["alert_rejected_min_score"]:
                await self.alerts.send(line)
            else:
                self.alerts.queue_digest(line)
            return
        if not executable:
            self.alerts.queue_digest(f"👀 shadow {tag}: {dec.summary}")
            return
        if self.pause_reason:
            await self.alerts.send(f"⏸ {tag} approved but trading paused: {self.pause_reason}")
            return
        size, why = size_trade(rcfg=self.cfg["risk"], exp=exp, chain=t.chain, token=t.token, leader=t.leader,
                               score=dec.score, min_score=vcfg["min_score"],
                               leader_weight=self.leader_weight(leader["score"] or 50))
        if size <= 0:
            await self.alerts.send(f"↪️ {tag} approved (score {dec.score:.0f}) but skipped: {why}")
            return
        gbp = await self.market.gbp_per_usd()
        pid = self.executor.buy(chain=t.chain, token=t.token, symbol=snap.symbol, leader=t.leader, signal_id=sid,
                                size_usd=size, price=snap.current_price, liquidity_usd=snap.liquidity_usd,
                                gas_usd=snap.gas_usd_per_swap, leader_price=t.price_usd, delay_s=snap.delay_s,
                                gbp_per_usd=gbp)
        self.db.ex("UPDATE signals SET position_id=? WHERE id=?", (pid, sid))
        move = f", {((snap.current_price / t.price_usd - 1) * 100):+.1f}% vs leader" if t.price_usd else ""
        await self.alerts.send(f"✅ [{self.executor.mode}] BUY {tag}\n£{size * gbp:.2f} at ${snap.current_price:.6g}"
                               f" (score {dec.score:.0f}, delay {snap.delay_s:.0f}s{move}, est cost {dec.est_cost_pct:.1f}%)")

    async def handle_leader_sell(self, t: LeaderTrade) -> None:
        if not self.cfg["risk"]["mirror_leader_sells"]:
            return
        rows = self.db.q("SELECT * FROM positions WHERE status='open' AND chain=? AND token=? AND leader=?",
                         (t.chain, t.token, t.leader))
        if not rows:
            return
        rpc = self.rpcs[t.chain]
        remaining_raw = await rpc.balance_of(t.token, t.leader)
        dec = await rpc.decimals(t.token)
        frac = 1.0
        if remaining_raw is not None and dec is not None:
            remaining = remaining_raw / 10 ** dec
            frac = t.token_amount / (t.token_amount + remaining) if (t.token_amount + remaining) > 0 else 1.0
            if frac >= 0.9:
                frac = 1.0
        await self.close_positions(rows, frac, f"leader sold {frac:.0%}")

    async def close_positions(self, rows, fraction: float, reason: str) -> None:
        gbp = await self.market.gbp_per_usd()
        for p in rows:
            ccfg = self.cfg["chains"][p["chain"]]
            pool = await self.market.token_pool(ccfg["gecko_network"], p["token"]) or {}
            price = pool.get("price_usd") or p["last_price"]
            if not price:
                continue
            pnl = self.executor.sell(position_id=p["id"], fraction=fraction, price=price,
                                     liquidity_usd=pool.get("liquidity_usd"), gas_usd=ccfg["gas_usd_per_swap"],
                                     reason=reason, gbp_per_usd=gbp)
            await self.alerts.send(f"{'🟢' if pnl >= 0 else '🔴'} [{self.executor.mode}] SELL {fraction:.0%} "
                                   f"{p['symbol']} ({reason}) P&L £{pnl * gbp:+.2f}")

    # ------------------------------------------------------------------ loops
    async def monitor_positions(self) -> None:
        r = self.cfg["risk"]
        while True:
            try:
                rows = self.db.q("SELECT * FROM positions WHERE status='open'")
                by_chain: dict[str, list] = {}
                for p in rows:
                    by_chain.setdefault(p["chain"], []).append(p)
                for chain, ps in by_chain.items():
                    prices = await self.market.token_prices(self.cfg["chains"][chain]["gecko_network"],
                                                            sorted({p["token"] for p in ps}))
                    for p in ps:
                        px = prices.get(p["token"])
                        if not px:
                            continue
                        self.db.ex("UPDATE positions SET last_price=? WHERE id=?", (px, p["id"]))
                        change = (px / p["entry_price"] - 1) * 100
                        age_d = (time.time() - p["opened_ts"]) / 86400
                        reason = None
                        if change <= -r["stop_loss_pct"]:
                            reason = f"stop-loss {change:.1f}%"
                        elif change >= r["take_profit_pct"]:
                            reason = f"take-profit {change:.1f}%"
                        elif age_d >= r["max_hold_days"]:
                            reason = f"max hold {age_d:.0f}d"
                        if reason:
                            await self.close_positions([p], 1.0, reason)
            except Exception:
                log.exception("position monitor error")
            await asyncio.sleep(60)

    async def equity_loop(self) -> None:
        while True:
            try:
                exp = self.exposure()
                self.db.ex("INSERT OR REPLACE INTO equity VALUES(?,?,?,?)",
                           (time.time(), exp.equity_usd, exp.cash_usd, exp.equity_usd - exp.cash_usd))
                reason = self.guard.check(exp.equity_usd)
                if reason != self.pause_reason:
                    await self.alerts.send(f"⏸ Trading paused: {reason}" if reason else "▶️ Trading resumed")
                    self.db.event("pause" if reason else "resume", reason or "")
                    self.pause_reason = reason
            except Exception:
                log.exception("equity loop error")
            await asyncio.sleep(300)

    async def scheduler(self) -> None:
        from . import improve, lifecycle

        lc = self.cfg["lifecycle"]
        while True:
            now = time.time()
            try:
                if now - self.db.kv_get("last_lifecycle", 0) > lc["discovery_interval_h"] * 3600:
                    self.db.kv_set("last_lifecycle", now)
                    changed = await lifecycle.run_daily(self)
                    if changed:
                        self.bump_leaders()
                await improve.track_outcomes(self)
                if self.cfg["improvement"]["enabled"] and now - self.db.kv_get("last_proposals", 0) > 7 * 86400:
                    self.db.kv_set("last_proposals", now)
                    await improve.weekly(self)
                hour = datetime.now(timezone.utc).hour
                today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
                if hour >= self.cfg["alerts"]["daily_summary_hour_utc"] and self.db.kv_get("last_summary") != today:
                    self.db.kv_set("last_summary", today)
                    await self.daily_summary()
            except Exception:
                log.exception("scheduler error")
            await asyncio.sleep(600)

    async def daily_summary(self) -> None:
        from .report import summary_text

        gbp = await self.market.gbp_per_usd()
        await self.alerts.send(summary_text(self.db, gbp, self.executor.mode))
        await self.alerts.flush_digest("🗒 Skipped / shadow signals today:")

    async def run(self) -> None:
        from .dashboard import start_dashboard

        self.seed_leaders()
        start_dashboard(self.db, self.cfg["dashboard"]["host"], self.cfg["dashboard"]["port"])
        mode = "LIVE" if self.cfg.is_live else "PAPER"
        await self.alerts.send(f"🤖 CopyBot started in {mode} mode, watching "
                               f"{len(self.db.leaders())} leaders on {', '.join(self.rpcs)}")
        tasks = [asyncio.create_task(self.watch_chain(c)) for c in self.rpcs]
        tasks += [asyncio.create_task(x) for x in (self.process_signals(), self.monitor_positions(),
                                                   self.equity_loop(), self.scheduler())]
        await asyncio.gather(*tasks)
