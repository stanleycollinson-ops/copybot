"""SQLite storage. One file in data_dir; safe to copy for backups."""
from __future__ import annotations

import json
import sqlite3
import time
from pathlib import Path
from typing import Any, Iterable, Optional

SCHEMA = """
CREATE TABLE IF NOT EXISTS leaders (
    address TEXT NOT NULL,
    chain TEXT NOT NULL,
    label TEXT,
    status TEXT NOT NULL DEFAULT 'probation',  -- candidate|probation|active|retired
    score REAL DEFAULT 0,
    metrics TEXT,               -- JSON from scoring
    funder TEXT,                -- first funding address (linked-wallet detection)
    niche TEXT,                 -- JSON: typical liquidity / size range
    median_trade_usd REAL,
    source TEXT,                -- seed|manual|discovery
    added_ts REAL,
    status_ts REAL,
    demotions INTEGER DEFAULT 0,
    probation_extended INTEGER DEFAULT 0,
    last_scored_ts REAL,
    PRIMARY KEY (address, chain)
);
CREATE TABLE IF NOT EXISTS leader_trades (
    tx_hash TEXT, chain TEXT, leader TEXT, token TEXT, side TEXT,
    token_amount REAL, quote_usd REAL, block INTEGER, ts REAL,
    PRIMARY KEY (tx_hash, leader, token, side)
);
CREATE TABLE IF NOT EXISTS signals (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ts REAL, chain TEXT, leader TEXT, token TEXT, symbol TEXT, side TEXT,
    tx_hash TEXT, mode TEXT,          -- live|paper|shadow
    approved INTEGER, score REAL, reasons TEXT, components TEXT,
    est_cost_pct REAL, snapshot TEXT,
    price_at_signal REAL, price_1h REAL, price_24h REAL,
    trial_approved INTEGER, trial_proposal_id INTEGER,
    position_id INTEGER
);
CREATE TABLE IF NOT EXISTS positions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    chain TEXT, token TEXT, symbol TEXT, leader TEXT, signal_id INTEGER,
    mode TEXT,                       -- paper|live
    status TEXT,                     -- open|closed
    qty REAL, cost_usd REAL, entry_price REAL, leader_price REAL,
    opened_ts REAL, closed_ts REAL, exit_price REAL, proceeds_usd REAL,
    realised_pnl_usd REAL, exit_reason TEXT, last_price REAL,
    delay_s REAL, fees_usd REAL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS fills (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ts REAL, position_id INTEGER, chain TEXT, token TEXT, symbol TEXT,
    side TEXT, qty REAL, price_usd REAL, value_usd REAL, fee_usd REAL,
    gbp_per_usd REAL, mode TEXT, tx_hash TEXT
);
CREATE TABLE IF NOT EXISTS account (
    key TEXT PRIMARY KEY, value TEXT
);
CREATE TABLE IF NOT EXISTS equity (
    ts REAL PRIMARY KEY, equity_usd REAL, cash_usd REAL, open_value_usd REAL
);
CREATE TABLE IF NOT EXISTS proposals (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    created_ts REAL, param TEXT, current_value TEXT, proposed_value TEXT,
    train_metric REAL, train_baseline REAL, test_metric REAL, test_baseline REAL,
    n_train INTEGER, n_test INTEGER,
    status TEXT,          -- proposed|trial|promoted|rejected
    trial_start_ts REAL, notes TEXT
);
CREATE TABLE IF NOT EXISTS overrides (
    param TEXT PRIMARY KEY, value TEXT, set_ts REAL, proposal_id INTEGER
);
CREATE TABLE IF NOT EXISTS events (
    id INTEGER PRIMARY KEY AUTOINCREMENT, ts REAL, kind TEXT, message TEXT
);
CREATE INDEX IF NOT EXISTS idx_signals_ts ON signals(ts);
CREATE INDEX IF NOT EXISTS idx_positions_status ON positions(status);
CREATE INDEX IF NOT EXISTS idx_leader_trades_leader ON leader_trades(leader, ts);
"""


class DB:
    def __init__(self, path: str | Path):
        self.path = str(path)
        self.conn = sqlite3.connect(self.path, check_same_thread=False, isolation_level=None)
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("PRAGMA journal_mode=WAL")
        self.conn.executescript(SCHEMA)

    # ---------- generic ----------
    def q(self, sql: str, params: Iterable[Any] = ()) -> list[sqlite3.Row]:
        return self.conn.execute(sql, tuple(params)).fetchall()

    def one(self, sql: str, params: Iterable[Any] = ()) -> Optional[sqlite3.Row]:
        return self.conn.execute(sql, tuple(params)).fetchone()

    def ex(self, sql: str, params: Iterable[Any] = ()) -> int:
        cur = self.conn.execute(sql, tuple(params))
        return cur.lastrowid

    # ---------- account / kv ----------
    def kv_get(self, key: str, default: Any = None) -> Any:
        row = self.one("SELECT value FROM account WHERE key=?", (key,))
        return json.loads(row["value"]) if row else default

    def kv_set(self, key: str, value: Any) -> None:
        self.ex("INSERT INTO account(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                (key, json.dumps(value)))

    def event(self, kind: str, message: str) -> None:
        self.ex("INSERT INTO events(ts,kind,message) VALUES(?,?,?)", (time.time(), kind, message))

    # ---------- leaders ----------
    def upsert_leader(self, address: str, chain: str, **fields: Any) -> None:
        address = address.lower()
        existing = self.one("SELECT * FROM leaders WHERE address=? AND chain=?", (address, chain))
        now = time.time()
        if existing is None:
            fields.setdefault("status", "probation")
            fields.setdefault("added_ts", now)
            fields.setdefault("status_ts", now)
            cols = ["address", "chain"] + list(fields)
            vals = [address, chain] + [json.dumps(v) if isinstance(v, (dict, list)) else v for v in fields.values()]
            self.ex(f"INSERT INTO leaders({','.join(cols)}) VALUES({','.join('?' * len(cols))})", vals)
        elif fields:
            if "status" in fields and fields["status"] != existing["status"]:
                fields["status_ts"] = now
            sets = ",".join(f"{k}=?" for k in fields)
            vals = [json.dumps(v) if isinstance(v, (dict, list)) else v for v in fields.values()]
            self.ex(f"UPDATE leaders SET {sets} WHERE address=? AND chain=?", vals + [address, chain])

    def leaders(self, statuses: Iterable[str] = ("probation", "active")) -> list[sqlite3.Row]:
        st = list(statuses)
        return self.q(f"SELECT * FROM leaders WHERE status IN ({','.join('?' * len(st))}) ORDER BY score DESC", st)

    def leader(self, address: str, chain: str) -> Optional[sqlite3.Row]:
        return self.one("SELECT * FROM leaders WHERE address=? AND chain=?", (address.lower(), chain))

    # ---------- trades / signals ----------
    def add_leader_trade(self, t: Any) -> bool:
        try:
            self.ex("INSERT INTO leader_trades VALUES(?,?,?,?,?,?,?,?,?)",
                    (t.tx_hash, t.chain, t.leader, t.token, t.side, t.token_amount, t.quote_usd, t.block, t.ts))
            return True
        except sqlite3.IntegrityError:
            return False  # duplicate (e.g. after reconnect)

    def add_signal(self, **f: Any) -> int:
        for k in ("reasons", "components", "snapshot"):
            if k in f and not isinstance(f[k], str):
                f[k] = json.dumps(f[k])
        cols = list(f)
        return self.ex(f"INSERT INTO signals({','.join(cols)}) VALUES({','.join('?' * len(cols))})", list(f.values()))

    # ---------- overrides ----------
    def overrides(self) -> dict[str, Any]:
        return {r["param"]: json.loads(r["value"]) for r in self.q("SELECT * FROM overrides")}
