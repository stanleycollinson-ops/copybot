"""Performance summaries used by alerts, the CLI and the go-live check."""
from __future__ import annotations

import statistics
import time


def performance(db, mode: str = "paper", since: float = 0.0) -> dict:
    start = db.kv_get("starting_cash_usd", 0.0) or 0.0
    eq = db.one("SELECT equity_usd FROM equity ORDER BY ts DESC LIMIT 1")
    equity = eq["equity_usd"] if eq else start
    closed = db.q("SELECT * FROM positions WHERE mode=? AND status='closed' AND closed_ts>?", (mode, since))
    pnls = [p["realised_pnl_usd"] or 0 for p in closed]
    opened = db.q("SELECT * FROM positions WHERE mode=? AND opened_ts>?", (mode, since))
    slips = [(p["entry_price"] / p["leader_price"] - 1) * 100 for p in opened if p["leader_price"]]
    delays = [p["delay_s"] for p in opened if p["delay_s"] is not None]
    fees = sum(p["fees_usd"] or 0 for p in opened)
    first = db.one("SELECT MIN(ts) t FROM equity")
    days = (time.time() - first["t"]) / 86400 if first and first["t"] else 0
    sig = db.one("SELECT COUNT(*) n, SUM(approved) a FROM signals WHERE side='buy' AND ts>?", (since,))
    return {
        "days_running": days,
        "start_usd": start,
        "equity_usd": equity,
        "return_pct": (equity / start - 1) * 100 if start else 0.0,
        "closed_trades": len(closed),
        "win_rate": (sum(1 for x in pnls if x > 0) / len(pnls)) if pnls else 0.0,
        "realised_pnl_usd": sum(pnls),
        "avg_entry_vs_leader_pct": statistics.mean(slips) if slips else None,
        "avg_delay_s": statistics.mean(delays) if delays else None,
        "fees_usd": fees,
        "signals": sig["n"] or 0,
        "approved": sig["a"] or 0,
        "open_positions": db.one("SELECT COUNT(*) n FROM positions WHERE status='open' AND mode=?", (mode,))["n"],
    }


def summary_text(db, gbp: float, mode: str) -> str:
    p = performance(db, mode)
    day = performance(db, mode, since=time.time() - 86400)
    lines = [
        f"📊 Daily summary ({mode})",
        f"Equity £{p['equity_usd'] * gbp:.2f} ({p['return_pct']:+.1f}% since start, {p['days_running']:.0f} days)",
        f"Today: {day['signals']} signals, {day['approved']} approved, {day['closed_trades']} closed, "
        f"realised £{day['realised_pnl_usd'] * gbp:+.2f}",
        f"Open positions: {p['open_positions']}",
    ]
    if p["avg_entry_vs_leader_pct"] is not None:
        lines.append(f"Copy cost: avg entry {p['avg_entry_vs_leader_pct']:+.1f}% vs leader, "
                     f"avg delay {p['avg_delay_s']:.0f}s, fees £{p['fees_usd'] * gbp:.2f} total")
    return "\n".join(lines)


def go_live_check(db, min_days: int = 14, min_trades: int = 15) -> list[tuple[bool, str]]:
    p = performance(db, "paper")
    return [
        (p["days_running"] >= min_days, f"Paper trading for {p['days_running']:.0f} days (need {min_days}+)"),
        (p["closed_trades"] >= min_trades, f"{p['closed_trades']} closed paper trades (need {min_trades}+)"),
        (p["return_pct"] > 0, f"Paper return after all costs {p['return_pct']:+.1f}% (need > 0)"),
        (bool(db.leaders(("active",))), f"{len(db.leaders(('active',)))} active leaders (need 1+)"),
    ]
