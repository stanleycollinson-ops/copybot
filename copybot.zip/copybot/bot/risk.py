"""Position sizing, exposure caps, loss limits and the kill switch."""
from __future__ import annotations

import time
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional


@dataclass
class Exposure:
    equity_usd: float
    cash_usd: float
    open_positions: int
    by_asset: dict[str, float]
    by_leader: dict[str, float]
    by_chain: dict[str, float]


def size_trade(*, rcfg: dict, exp: Exposure, chain: str, token: str, leader: str,
               score: float, min_score: float, leader_weight: float) -> tuple[float, str]:
    """Return (size_usd, reason). size 0 means skip."""
    if exp.open_positions >= rcfg["max_open_positions"]:
        return 0.0, "max open positions reached"
    eq = exp.equity_usd
    # scale base size by signal quality (60% at threshold -> 100% at score 100) and leader weight
    span = max(100 - min_score, 1)
    quality = 0.6 + 0.4 * max(0.0, min((score - min_score) / span, 1.0))
    weight = max(0.5, min(leader_weight, 1.5))
    size = eq * rcfg["max_trade_pct"] / 100 * quality * weight
    caps = {
        "per-trade cap": eq * rcfg["max_trade_pct"] / 100,
        "asset cap": eq * rcfg["max_per_asset_pct"] / 100 - exp.by_asset.get(f"{chain}:{token}", 0.0),
        "leader cap": eq * rcfg["max_per_leader_pct"] / 100 - exp.by_leader.get(leader, 0.0),
        "chain cap": eq * rcfg["max_per_chain_pct"] / 100 - exp.by_chain.get(chain, 0.0),
        "cash": exp.cash_usd * 0.98,
    }
    binding = None
    for name, cap in caps.items():
        if cap < size:
            size, binding = cap, name
    if size < rcfg["min_trade_usd"]:
        return 0.0, f"size ${max(size, 0):.2f} below minimum ({binding or 'sizing'})"
    return round(size, 2), binding or "ok"


class RiskGuard:
    """Tracks day/week starting equity and pauses new entries when loss limits are hit."""

    def __init__(self, db, rcfg: dict, data_dir: Path):
        self.db, self.rcfg = db, rcfg
        self.kill_file = data_dir / "KILL"

    def killed(self) -> bool:
        return self.kill_file.exists() or bool(self.db.kv_get("kill", False))

    def _period_keys(self, now: Optional[float] = None) -> tuple[str, str]:
        d = datetime.fromtimestamp(now or time.time(), tz=timezone.utc)
        iso = d.isocalendar()
        return d.strftime("%Y-%m-%d"), f"{iso[0]}-W{iso[1]:02d}"

    def check(self, equity_usd: float, now: Optional[float] = None) -> Optional[str]:
        """Return a pause reason, or None if trading may continue."""
        if self.killed():
            return "kill switch is on"
        day, week = self._period_keys(now)
        start = self.db.kv_get("period_start", {})
        changed = False
        if start.get("day") != day:
            start.update(day=day, day_equity=equity_usd)
            changed = True
        if start.get("week") != week:
            start.update(week=week, week_equity=equity_usd)
            changed = True
        if changed:
            self.db.kv_set("period_start", start)
        day_loss = (1 - equity_usd / start["day_equity"]) * 100 if start["day_equity"] else 0
        week_loss = (1 - equity_usd / start["week_equity"]) * 100 if start["week_equity"] else 0
        if day_loss >= self.rcfg["daily_loss_limit_pct"]:
            return f"daily loss limit hit ({day_loss:.1f}%), paused until 00:00 UTC"
        if week_loss >= self.rcfg["weekly_loss_limit_pct"]:
            return f"weekly loss limit hit ({week_loss:.1f}%), paused until Monday 00:00 UTC"
        return None
