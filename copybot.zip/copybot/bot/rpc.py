"""Alchemy JSON-RPC access (HTTP for calls, WebSocket for live log subscriptions)."""
from __future__ import annotations

import asyncio
import json
import logging
from typing import Any, AsyncIterator, Optional

from .net import RateLimiter, TTLCache, post_json

log = logging.getLogger("rpc")

_DECIMALS_SIG = "0x313ce567"
_SYMBOL_SIG = "0x95d89b41"
_BALANCEOF_SIG = "0x70a08231"


class ChainRPC:
    def __init__(self, chain: str, alchemy_slug: str, api_key: str):
        if not api_key:
            raise SystemExit("ALCHEMY_API_KEY is not set. Add it to your .env file (see README step 3).")
        self.chain = chain
        self.http_url = f"https://{alchemy_slug}.g.alchemy.com/v2/{api_key}"
        self.ws_url = f"wss://{alchemy_slug}.g.alchemy.com/v2/{api_key}"
        self.limiter = RateLimiter(20, 1.0)
        self.cache = TTLCache()
        self._id = 0

    async def call(self, method: str, params: list) -> Any:
        self._id += 1
        res = await post_json(self.http_url, {"jsonrpc": "2.0", "id": self._id, "method": method, "params": params},
                              limiter=self.limiter)
        if not res:
            return None
        if "error" in res:
            log.debug("%s %s error: %s", self.chain, method, res["error"])
            return None
        return res.get("result")

    # ----- helpers -----
    async def decimals(self, token: str) -> Optional[int]:
        key = f"dec:{token}"
        hit = self.cache.get(key)
        if hit is not None:
            return hit
        r = await self.call("eth_call", [{"to": token, "data": _DECIMALS_SIG}, "latest"])
        try:
            d = int(r, 16) if r and r != "0x" else None
        except ValueError:
            d = None
        if d is not None and d <= 36:
            self.cache.set(key, d, 7 * 86400)
            return d
        return None

    async def symbol(self, token: str) -> str:
        key = f"sym:{token}"
        hit = self.cache.get(key)
        if hit is not None:
            return hit
        r = await self.call("eth_call", [{"to": token, "data": _SYMBOL_SIG}, "latest"])
        sym = ""
        try:
            raw = bytes.fromhex((r or "0x")[2:])
            if len(raw) >= 96:
                n = int.from_bytes(raw[32:64], "big")
                sym = raw[64:64 + n].decode("utf-8", "ignore")
            elif raw:
                sym = raw.rstrip(b"\x00").decode("utf-8", "ignore")
        except Exception:
            pass
        sym = "".join(ch for ch in sym if ch.isprintable())[:16] or token[:8]
        self.cache.set(key, sym, 7 * 86400)
        return sym

    async def balance_of(self, token: str, owner: str, block: str = "latest") -> Optional[int]:
        data = _BALANCEOF_SIG + owner.lower().replace("0x", "").rjust(64, "0")
        r = await self.call("eth_call", [{"to": token, "data": data}, block])
        try:
            return int(r, 16) if r and r != "0x" else None
        except ValueError:
            return None

    async def native_balance(self, owner: str, block: int) -> Optional[int]:
        r = await self.call("eth_getBalance", [owner, hex(block)])
        return int(r, 16) if r else None

    async def block_ts(self, block: int) -> Optional[float]:
        key = f"blk:{block}"
        hit = self.cache.get(key)
        if hit is not None:
            return hit
        b = await self.call("eth_getBlockByNumber", [hex(block), False])
        if not b:
            return None
        ts = float(int(b["timestamp"], 16))
        self.cache.set(key, ts, 3600)
        return ts

    async def native_received_in_tx(self, owner: str, receipt: dict) -> float:
        """ETH received by `owner` in a tx (e.g. a token sold for native ETH), using the balance change
        across the block plus gas paid. Approximate if the owner has several txs in that block."""
        block = int(receipt["blockNumber"], 16)
        before = await self.native_balance(owner, block - 1)
        after = await self.native_balance(owner, block)
        if before is None or after is None:
            return 0.0
        gas = int(receipt.get("gasUsed", "0x0"), 16) * int(receipt.get("effectiveGasPrice", "0x0"), 16)
        l1 = int(receipt.get("l1Fee", "0x0") or "0x0", 16)  # OP-stack chains (Base)
        delta = after - before + gas + l1
        return max(delta, 0) / 1e18

    async def asset_transfers(self, *, address: str, direction: str, categories: list[str],
                              max_pages: int = 5, from_block: str = "0x0",
                              contract: Optional[str] = None, order: str = "desc") -> list[dict]:
        out: list[dict] = []
        page_key = None
        for _ in range(max_pages):
            p: dict[str, Any] = {"fromBlock": from_block, "toBlock": "latest", "category": categories,
                                 "withMetadata": True, "excludeZeroValue": True, "maxCount": "0x3e8", "order": order}
            if direction == "from":
                p["fromAddress"] = address
            elif direction == "to":
                p["toAddress"] = address
            if contract:
                p["contractAddresses"] = [contract]
            if page_key:
                p["pageKey"] = page_key
            res = await self.call("alchemy_getAssetTransfers", [p])
            if not res:
                break
            out.extend(res.get("transfers", []))
            page_key = res.get("pageKey")
            if not page_key:
                break
        return out

    async def token_transfers(self, token: str, max_pages: int = 1) -> list[dict]:
        """Earliest ERC-20 transfers of a token (used to find early buyers)."""
        out: list[dict] = []
        page_key = None
        for _ in range(max_pages):
            p: dict[str, Any] = {"fromBlock": "0x0", "toBlock": "latest", "category": ["erc20"],
                                 "contractAddresses": [token], "withMetadata": True, "excludeZeroValue": True,
                                 "maxCount": "0x3e8", "order": "asc"}
            if page_key:
                p["pageKey"] = page_key
            res = await self.call("alchemy_getAssetTransfers", [p])
            if not res:
                break
            out.extend(res.get("transfers", []))
            page_key = res.get("pageKey")
            if not page_key:
                break
        return out

    async def first_funder(self, address: str) -> Optional[str]:
        res = await self.call("alchemy_getAssetTransfers", [{
            "fromBlock": "0x0", "toBlock": "latest", "toAddress": address, "category": ["external"],
            "excludeZeroValue": True, "maxCount": "0x1", "order": "asc"}])
        try:
            return res["transfers"][0]["from"].lower()
        except (TypeError, KeyError, IndexError):
            return None

    # ----- live subscription -----
    async def subscribe_transfer_logs(self, addresses: list[str]) -> AsyncIterator[dict]:
        """Yield every ERC-20 Transfer log where any of `addresses` is sender or receiver.
        Reconnects forever with backoff; the caller re-creates the generator when the leader set changes."""
        import websockets  # lazy import

        from .parse import TRANSFER_TOPIC, address_to_topic

        topics = [address_to_topic(a) for a in addresses]
        backoff = 2
        while True:
            try:
                async with websockets.connect(self.ws_url, ping_interval=20, max_size=2**22) as ws:
                    for i, filt in enumerate(([TRANSFER_TOPIC, topics], [TRANSFER_TOPIC, None, topics])):
                        await ws.send(json.dumps({"jsonrpc": "2.0", "id": i + 1, "method": "eth_subscribe",
                                                  "params": ["logs", {"topics": filt}]}))
                    log.info("%s: subscribed to transfers for %d leaders", self.chain, len(addresses))
                    backoff = 2
                    async for raw in ws:
                        msg = json.loads(raw)
                        if msg.get("method") == "eth_subscription":
                            result = msg["params"]["result"]
                            if not result.get("removed"):
                                yield result
            except asyncio.CancelledError:
                raise
            except Exception as e:
                log.warning("%s websocket dropped (%s); reconnecting in %ss", self.chain, e, backoff)
                await asyncio.sleep(backoff)
                backoff = min(backoff * 2, 60)
