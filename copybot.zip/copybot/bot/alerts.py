"""Telegram alerts. If no token is configured, messages just go to the log."""
from __future__ import annotations

import logging

from .net import RateLimiter, post_json

log = logging.getLogger("alerts")
_limiter = RateLimiter(20, 60.0)


class Alerts:
    def __init__(self, token: str, chat_id: str, enabled: bool = True):
        self.enabled = enabled and bool(token and chat_id)
        self.url = f"https://api.telegram.org/bot{token}/sendMessage" if token else ""
        self.chat_id = chat_id
        self.digest: list[str] = []

    async def send(self, text: str) -> None:
        log.info("ALERT %s", text.replace("\n", " | "))
        if not self.enabled:
            return
        await post_json(self.url, {"chat_id": self.chat_id, "text": text[:4000], "disable_web_page_preview": True},
                        limiter=_limiter, retries=2)

    def queue_digest(self, line: str) -> None:
        self.digest.append(line)
        self.digest = self.digest[-200:]

    async def flush_digest(self, header: str) -> None:
        if not self.digest:
            return
        body = "\n".join(self.digest[-40:])
        extra = f"\n(+{len(self.digest) - 40} more)" if len(self.digest) > 40 else ""
        self.digest = []
        await self.send(f"{header}\n{body}{extra}")
