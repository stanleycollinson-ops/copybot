"""Self-improvement, done safely.

1. track_outcomes: records each signal's price 1h and 24h later (approved AND rejected),
   so we learn which filters saved money and which skipped winners.
2. weekly: re-runs stored decisions under nearby thresholds. A change is only PROPOSED if it
   beats the current setting on older data (train) AND on the most recent data it wasn't fitted
   on (test). Nothing changes automatically.
3. You start a trial (`cli trial ID`): the proposal is evaluated live, side by side, for N days.
4. You promote it (`cli promote ID`) only if the trial also beats the current setting.
"""
from __future__ import annotations

import json
import logging
import re
import statistics
import time
from typing import Any

from .config import TUNABLE_PARAMS, get_path, set_path
from .models import Snapshot
from .validator import validate

log = logging.getLogger("improve")


async def track_outcomes(engine) -> None:
    db = engine.db
    now = time.time()
    due = db.q("SELECT id, chain, token, ts, price_1h, price_24h FROM signals WHERE side='buy' AND "
               "((price_1h IS NULL AND ts < ?) OR (price_24h IS NULL AND ts < ?)) AND ts > ?",
               (now - 3600, now - 86400, now - 3 * 86400))
    by_chain: dict[str, list] = {}
    for r in due:
        by_chain.setdefault(r["chain"], []).append(r)
    for chain, rows in by_chain.items():
        if chain not in engine.cfg["chains"]:
            continue
        prices = await engine.bg_market.token_prices(engine.cfg["chains"][chain]["gecko_network"],
                                                     sorted({r["token"] for r in rows}))
        for r in rows:
            px = prices.get(r["token"])
            if px is None:
                continue
            if r["price_1h"] is None and r["ts"] < now - 3600:
                db.ex("UPDATE signals SET price_1h=? WHERE id=?", (px, r["id"]))
            if r["price_24h"] is None and r["ts"] < now - 86400:
                db.ex("UPDATE signals SET price_24h=? WHERE id=?", (px, r["id"]))


def signal_outcomes(db, since: float = 0.0) -> list[dict[str, Any]]:
    rows = db.q("SELECT id, ts, snapshot, price_at_signal, price_24h, trial_approved, trial_proposal_id, approved "
                "FROM signals WHERE side='buy' AND price_24h IS NOT NULL AND price_at_signal > 0 AND ts > ? "
                "ORDER BY ts", (since,))
    out = []
    for r in rows:
        out.append({"id": r["id"], "ts": r["ts"], "snap": Snapshot.from_dict(json.loads(r["snapshot"])),
                    "ret_pct": (r["price_24h"] / r["price_at_signal"] - 1) * 100,
                    "approved": r["approved"], "trial_approved": r["trial_approved"],
                    "trial_proposal_id": r["trial_proposal_id"]})
    return out


def evaluate(outcomes: list[dict], vcfg: dict) -> tuple[float, int]:
    """Total net return (sum of % returns after costs) of the signals this config would take."""
    total, n = 0.0, 0
    for o in outcomes:
        d = validate(o["snap"], vcfg)
        if d.approved:
            total += o["ret_pct"] - d.est_cost_pct
            n += 1
    return total, n


def filter_report(outcomes: list[dict], vcfg: dict) -> list[str]:
    """Which hard filters saved money (rejected losers) vs cost money (rejected winners)."""
    stats: dict[str, list[float]] = {}
    for o in outcomes:
        d = validate(o["snap"], vcfg)
        for reason in d.reasons:
            key = re.sub(r"\s+", " ", re.sub(r"\$?[\d.,]+%?s?", "", reason)).strip()  # drop the numbers
            stats.setdefault(key, []).append(o["ret_pct"])
    lines = []
    for k, rets in sorted(stats.items(), key=lambda kv: -len(kv[1])):
        avg = statistics.mean(rets)
        verdict = "saved money" if avg < 0 else "skipped winners"
        lines.append(f"{k}: {len(rets)} rejects, avg 24h move {avg:+.1f}% ({verdict})")
    return lines


def propose(outcomes: list[dict], cfg_raw: dict, icfg: dict) -> list[dict]:
    n = len(outcomes)
    split = int(n * icfg["train_fraction"])
    train, test = outcomes[:split], outcomes[split:]
    if len(train) < icfg["min_train_signals"] or len(test) < icfg["min_test_signals"]:
        return []
    proposals = []
    for param, (step, lo, hi) in TUNABLE_PARAMS.items():
        cur = get_path(cfg_raw, param)
        base_tr, _ = evaluate(train, set_path(cfg_raw, param, cur)["validation"])
        base_te, _ = evaluate(test, set_path(cfg_raw, param, cur)["validation"])
        best = None
        for cand in (cur - step, cur + step):
            if cand < lo or cand > hi:
                continue
            vc = set_path(cfg_raw, param, cand)["validation"]
            tr, n_tr = evaluate(train, vc)
            te, n_te = evaluate(test, vc)
            gain = tr - base_tr
            if gain >= icfg["min_improvement_pct"] and te > base_te and n_tr >= 5:
                if best is None or gain > best["gain"]:
                    best = dict(param=param, current=cur, proposed=cand, train=tr, train_base=base_tr,
                                test=te, test_base=base_te, n_train=len(train), n_test=len(test), gain=gain)
        if best:
            proposals.append(best)
    return proposals


async def weekly(engine) -> None:
    db = engine.db
    outcomes = signal_outcomes(db, since=time.time() - 120 * 86400)
    lines = filter_report(outcomes[-500:], engine.cfg["validation"])
    new = propose(outcomes, engine.cfg.raw, engine.cfg["improvement"])
    for p in new:
        open_dupe = db.one("SELECT id FROM proposals WHERE param=? AND status IN ('proposed','trial')", (p["param"],))
        if open_dupe:
            continue
        pid = db.ex("INSERT INTO proposals(created_ts,param,current_value,proposed_value,train_metric,train_baseline,"
                    "test_metric,test_baseline,n_train,n_test,status) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                    (time.time(), p["param"], json.dumps(p["current"]), json.dumps(p["proposed"]), p["train"],
                     p["train_base"], p["test"], p["test_base"], p["n_train"], p["n_test"], "proposed"))
        lines.append(f"💡 Proposal #{pid}: {p['param']} {p['current']} → {p['proposed']} "
                     f"(train {p['train_base']:+.0f}→{p['train']:+.0f}, test {p['test_base']:+.0f}→{p['test']:+.0f}). "
                     f"Start a trial with: python -m bot.cli trial {pid}")
    trial = db.one("SELECT * FROM proposals WHERE status='trial'")
    if trial:
        lines.append(trial_status(db, trial, engine.cfg["improvement"]["trial_days"]))
    if not lines:
        lines = [f"Not enough data yet ({len(outcomes)} signals with 24h outcomes)."]
    await engine.alerts.send("📈 Weekly strategy review\n" + "\n".join(lines))


def trial_status(db, trial, trial_days: int) -> str:
    outs = [o for o in signal_outcomes(db, since=trial["trial_start_ts"] or 0)
            if o["trial_proposal_id"] == trial["id"]]
    cur = sum(o["ret_pct"] for o in outs if o["approved"])
    new = sum(o["ret_pct"] for o in outs if o["trial_approved"])
    days = (time.time() - (trial["trial_start_ts"] or time.time())) / 86400
    verdict = "ready to promote" if days >= trial_days and new > cur and len(outs) >= 10 else "keep waiting"
    return (f"🧪 Trial #{trial['id']} ({trial['param']}): day {days:.0f}/{trial_days}, {len(outs)} signals, "
            f"current {cur:+.0f}% vs proposed {new:+.0f}% ({verdict})")


def start_trial(db, pid: int) -> str:
    p = db.one("SELECT * FROM proposals WHERE id=?", (pid,))
    if not p or p["status"] != "proposed":
        return "No open proposal with that id."
    if db.one("SELECT id FROM proposals WHERE status='trial'"):
        return "Another trial is already running; promote or reject it first."
    db.ex("UPDATE proposals SET status='trial', trial_start_ts=? WHERE id=?", (time.time(), pid))
    return f"Trial started for proposal #{pid}. The running bot picks it up on the next signal."


def promote(db, pid: int, trial_days: int, force: bool = False) -> str:
    p = db.one("SELECT * FROM proposals WHERE id=?", (pid,))
    if not p or p["status"] != "trial":
        return "That proposal is not on trial."
    outs = [o for o in signal_outcomes(db, since=p["trial_start_ts"]) if o["trial_proposal_id"] == pid]
    cur = sum(o["ret_pct"] for o in outs if o["approved"])
    new = sum(o["ret_pct"] for o in outs if o["trial_approved"])
    days = (time.time() - p["trial_start_ts"]) / 86400
    if not force and (days < trial_days or len(outs) < 10 or new <= cur):
        return (f"Not promoted: day {days:.0f}/{trial_days}, {len(outs)} signals, current {cur:+.0f}% vs "
                f"proposed {new:+.0f}%. The trial must run its full length and beat the current setting.")
    db.ex("INSERT OR REPLACE INTO overrides(param,value,set_ts,proposal_id) VALUES(?,?,?,?)",
          (p["param"], p["proposed_value"], time.time(), pid))
    db.ex("UPDATE proposals SET status='promoted' WHERE id=?", (pid,))
    db.event("override", f"{p['param']} = {p['proposed_value']} (proposal #{pid})")
    return f"Promoted: {p['param']} is now {p['proposed_value']}. Restart the bot to apply."


def reject(db, pid: int) -> str:
    db.ex("UPDATE proposals SET status='rejected' WHERE id=? AND status IN ('proposed','trial')", (pid,))
    return f"Proposal #{pid} rejected."
