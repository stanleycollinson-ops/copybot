"""CopyBot: multi-leader on-chain copy-trading bot (paper mode by default)."""

__version__ = "0.1.0"
