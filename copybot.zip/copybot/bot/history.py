"""Fetch a wallet's trade history, score it, and replay its trades as a follower would have."""
from __future__ import annotations

import logging
import statistics
import time
from dataclasses import dataclass
from typing import Optional

from .market import Market, price_at
from .models import LeaderTrade
from .parse import build_trades, group_asset_transfers
from .rpc import ChainRPC
from .scoring import LeaderMetrics, compute_metrics, score_metrics
from .validator import estimate_cost_pct

log = logging.getLogger("history")


async def fetch_trades(rpc: ChainRPC, market: Market, chain_cfg: dict, chain: str, wallet: str,
                       days: int = 90) -> list[LeaderTrade]:
    wallet = wallet.lower()
    rows = await rpc.asset_transfers(address=wallet, direction="from", categories=["erc20", "external"], max_pages=4)
    rows += await rpc.asset_transfers(address=wallet, direction="to", categories=["erc20"], max_pages=4)
    cutoff = time.time() - days * 86400
    groups = group_asset_transfers(rows, wallet)
    eth_hist = await market.eth_usd_history(days=min(days, 90))
    trades: list[LeaderTrade] = []
    base_assets = chain_cfg["base_assets"]
    for h, g in groups.items():
        if not g["leader_initiated"] or (g["ts"] and g["ts"] < cutoff):
            continue
        eth_usd = price_at(eth_hist, g["ts"]) if eth_hist else None
        native_received = 0.0
        sent_tokens = [t for t in g["transfers"] if t.frm == wallet and t.token not in base_assets]
        got_base = any(t.to == wallet and t.token in base_assets for t in g["transfers"])
        if sent_tokens and not got_base:
            # sold for native ETH, which ERC-20 transfer data can't show: measure balance change instead
            receipt = await rpc.call("eth_getTransactionReceipt", [h])
            if receipt:
                native_received = await rpc.native_received_in_tx(wallet, receipt)
        trades.extend(build_trades(chain=chain, leader=wallet, tx_hash=h, block=g["block"], ts=g["ts"],
                                   transfers=g["transfers"], base_assets=base_assets, eth_usd=eth_usd,
                                   native_sent=g["native_sent"], native_received=native_received))
    trades.sort(key=lambda t: t.ts)
    return trades


@dataclass
class ReplayResult:
    token: str
    leader_entry: float
    copy_entry: float
    copy_exit: Optional[float]
    exit_kind: str  # leader_sell|still_open|no_data
    leader_return_pct: Optional[float]
    copy_return_pct: Optional[float]  # after fees, slippage and gas


async def replay(market: Market, network: str, trades: list[LeaderTrade], *, delay_s: float, size_usd: float,
                 dex_fee_pct: float, gas_usd: float, max_trades: int = 20) -> list[ReplayResult]:
    """Re-run a leader's recent buys as a follower entering `delay_s` later and exiting `delay_s` after the
    leader's first subsequent sell (or marking to market if still open)."""
    buys = [t for t in trades if t.side == "buy" and t.price_usd][-max_trades:]
    results: list[ReplayResult] = []
    for b in buys:
        pool = await market.token_pool(network, b.token)
        if not pool:
            results.append(ReplayResult(b.token, b.price_usd, 0, None, "no_data", None, None))
            continue
        series = await market.ohlcv_minute(network, pool["pool"], b.ts + delay_s + 3600, limit=120,
                                           token_is_base=pool["token_is_base"])
        entry = price_at(series, b.ts + delay_s)
        if not entry:
            results.append(ReplayResult(b.token, b.price_usd, 0, None, "no_data", None, None))
            continue
        sell = next((t for t in trades if t.side == "sell" and t.token == b.token and t.ts > b.ts), None)
        if sell:
            s2 = await market.ohlcv_minute(network, pool["pool"], sell.ts + delay_s + 3600, limit=120,
                                           token_is_base=pool["token_is_base"])
            exit_px, kind = price_at(s2, sell.ts + delay_s), "leader_sell"
            leader_ret = ((sell.price_usd / b.price_usd - 1) * 100) if sell.price_usd else None
        else:
            exit_px, kind = pool["price_usd"], "still_open"
            leader_ret = ((exit_px / b.price_usd - 1) * 100) if exit_px else None
        cost = estimate_cost_pct(size_usd, pool["liquidity_usd"], dex_fee_pct, gas_usd)
        copy_ret = ((exit_px / entry - 1) * 100 - cost) if exit_px else None
        results.append(ReplayResult(b.token, b.price_usd, entry, exit_px, kind, leader_ret, copy_ret))
    return results


async def score_wallet(rpc: ChainRPC, market: Market, cfg, chain: str, wallet: str,
                       with_replay: bool = True) -> tuple[LeaderMetrics, list[LeaderTrade]]:
    chain_cfg = cfg["chains"][chain]
    scfg = dict(cfg["scoring"])
    scfg["sniper_window_s"] = cfg["discovery"]["sniper_window_min"] * 60
    trades = await fetch_trades(rpc, market, chain_cfg, chain, wallet, days=scfg["history_days"])
    # pool creation times for sniper detection (only for tokens bought, capped to limit API use)
    created: dict[str, float] = {}
    for tok in list({t.token for t in trades if t.side == "buy"})[:10]:
        p = await market.token_pool(chain_cfg["gecko_network"], tok)
        if p and p.get("created_ts"):
            created[tok] = p["created_ts"]
    m = compute_metrics(trades, scfg, time.time(), created)
    if with_replay and not m.flags:
        size = cfg["capital_gbp"] / 0.75 * cfg["risk"]["max_trade_pct"] / 100
        res = await replay(market, chain_cfg["gecko_network"], trades, delay_s=scfg["replay_delay_s"],
                           size_usd=size, dex_fee_pct=cfg["validation"]["dex_fee_pct"],
                           gas_usd=chain_cfg["gas_usd_per_swap"], max_trades=scfg["replay_trades"])
        rets = [r.copy_return_pct for r in res if r.copy_return_pct is not None]
        if rets:
            m.copy_return_pct = statistics.mean(rets)
            m.copy_n = len(rets)
            if len(rets) >= 5 and m.copy_return_pct < 0:
                m.flags.append("not copyable after costs")
        m.score = score_metrics(m)
    return m, trades
