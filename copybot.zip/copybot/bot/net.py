"""HTTP helpers: shared client, per-host rate limiting, small TTL cache, retries."""
from __future__ import annotations

import asyncio
import logging
import time
from typing import Any, Optional

log = logging.getLogger("net")


class RateLimiter:
    """Allow at most `calls` requests every `period` seconds."""

    def __init__(self, calls: int, period: float):
        self.calls, self.period = calls, period
        self.stamps: list[float] = []
        self.lock = asyncio.Lock()

    async def wait(self) -> None:
        async with self.lock:
            while True:
                now = time.monotonic()
                self.stamps = [s for s in self.stamps if now - s < self.period]
                if len(self.stamps) < self.calls:
                    self.stamps.append(now)
                    return
                await asyncio.sleep(self.period - (now - self.stamps[0]) + 0.05)


class TTLCache:
    def __init__(self) -> None:
        self.data: dict[str, tuple[float, Any]] = {}

    def get(self, key: str) -> Any:
        hit = self.data.get(key)
        if hit and hit[0] > time.time():
            return hit[1]
        return None

    def set(self, key: str, value: Any, ttl: float) -> None:
        self.data[key] = (time.time() + ttl, value)
        if len(self.data) > 5000:  # crude cap
            for k in list(self.data)[:1000]:
                self.data.pop(k, None)


_client = None


def client():
    global _client
    if _client is None:
        import httpx  # imported lazily so pure-logic modules work without it

        _client = httpx.AsyncClient(timeout=20.0, headers={"User-Agent": "copybot/0.1"})
    return _client


async def get_json(url: str, *, params: Optional[dict] = None, headers: Optional[dict] = None,
                   limiter: Optional[RateLimiter] = None, retries: int = 3) -> Any:
    delay = 2.0
    for attempt in range(retries):
        if limiter:
            await limiter.wait()
        try:
            r = await client().get(url, params=params, headers=headers)
            if r.status_code == 429:
                log.warning("rate limited by %s, backing off %.0fs", url.split("/")[2], delay * 5)
                await asyncio.sleep(delay * 5)
                delay *= 2
                continue
            if r.status_code == 404:
                return None
            r.raise_for_status()
            return r.json()
        except Exception as e:  # network blips are normal on a 24/7 bot
            if attempt == retries - 1:
                log.warning("GET %s failed: %s", url, e)
                return None
            await asyncio.sleep(delay)
            delay *= 2
    return None


async def post_json(url: str, payload: Any, *, limiter: Optional[RateLimiter] = None, retries: int = 3) -> Any:
    delay = 1.0
    for attempt in range(retries):
        if limiter:
            await limiter.wait()
        try:
            r = await client().post(url, json=payload)
            if r.status_code == 429:
                await asyncio.sleep(delay * 3)
                delay *= 2
                continue
            r.raise_for_status()
            return r.json()
        except Exception as e:
            if attempt == retries - 1:
                log.warning("POST %s failed: %s", url.split("?")[0], e)
                return None
            await asyncio.sleep(delay)
            delay *= 2
    return None
