"""Plain data types shared across modules."""
from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any, Optional


@dataclass
class TokenTransfer:
    token: str  # lower-case contract address, or "native"
    frm: str
    to: str
    amount: float  # already scaled by decimals
    log_index: int = 0


@dataclass
class LeaderTrade:
    """A buy or sell of a non-base token by a leader, reconstructed from one transaction."""
    chain: str
    leader: str
    tx_hash: str
    block: int
    ts: float  # unix seconds of the block
    side: str  # "buy" or "sell"
    token: str
    token_amount: float
    quote_usd: Optional[float] = None  # USD value of base assets paid/received, if observable

    @property
    def price_usd(self) -> Optional[float]:
        if self.quote_usd and self.token_amount:
            return self.quote_usd / self.token_amount
        return None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class Snapshot:
    """Everything the validator needs to judge one buy signal. Stored with every signal
    so the improvement job can replay decisions under different thresholds."""
    chain: str
    token: str
    symbol: str = ""
    leader: str = ""
    leader_status: str = "active"
    leader_score: float = 50.0
    leader_median_trade_usd: Optional[float] = None
    leader_trade_usd: Optional[float] = None
    leader_niche_match: bool = True
    leader_recent_sells_1h: int = 0
    leader_price: Optional[float] = None
    delay_s: float = 0.0
    current_price: Optional[float] = None
    liquidity_usd: Optional[float] = None
    volume_24h_usd: Optional[float] = None
    price_change_h1: Optional[float] = None
    price_change_h24: Optional[float] = None
    token_age_h: Optional[float] = None
    # token safety (None = unknown)
    is_honeypot: Optional[bool] = None
    cannot_sell_all: Optional[bool] = None
    buy_tax_pct: Optional[float] = None
    sell_tax_pct: Optional[float] = None
    is_open_source: Optional[bool] = None
    is_mintable: Optional[bool] = None
    owner_change_balance: Optional[bool] = None
    transfer_pausable: Optional[bool] = None
    slippage_modifiable: Optional[bool] = None
    is_blacklisted: Optional[bool] = None
    hidden_owner: Optional[bool] = None
    lp_locked_pct: Optional[float] = None
    top10_holder_pct: Optional[float] = None
    # context
    btc_risk_on: Optional[bool] = None
    consensus_independent: int = 1
    trade_size_usd: float = 0.0
    gas_usd_per_swap: float = 0.1

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "Snapshot":
        known = {k: v for k, v in d.items() if k in cls.__dataclass_fields__}
        return cls(**known)


@dataclass
class Decision:
    approved: bool
    score: float
    reasons: list[str] = field(default_factory=list)  # hard-fail reasons
    components: dict[str, float] = field(default_factory=dict)
    est_cost_pct: float = 0.0

    @property
    def summary(self) -> str:
        if self.approved:
            return f"APPROVED score={self.score:.0f}"
        why = "; ".join(self.reasons) if self.reasons else f"score {self.score:.0f} below threshold"
        return f"REJECTED score={self.score:.0f}: {why}"
