"""Configuration loading.

Settings come from config.yaml (copy config.example.yaml). Secrets come ONLY from
environment variables / .env, never from the YAML file. Parameter changes approved
through the improvement workflow are stored in the database as overrides and
layered on top of the YAML at start-up.
"""
from __future__ import annotations

import copy
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

DEFAULTS: dict[str, Any] = {
    "mode": "paper",  # "paper" or "live". Live is refused unless allow_live is also true.
    "allow_live": False,
    "data_dir": "data",
    "capital_gbp": 200.0,
    "gbp_per_usd_fallback": 0.75,
    "chains": {
        "base": {
            "enabled": True,
            "chain_id": 8453,
            "gecko_network": "base",
            "alchemy_slug": "base-mainnet",
            "gas_usd_per_swap": 0.05,
            "native_symbol": "ETH",
            "wrapped_native": "0x4200000000000000000000000000000000000006",
            "base_assets": {
                "0x4200000000000000000000000000000000000006": "WETH",
                "0x833589fcd6edb6e08f4c7c32d4f71b54bda02913": "USDC",
                "0xd9aaec86b65d86f6a7b5b1b0c42ffa531710b6ca": "USDbC",
                "0x50c5725949a6f0c72e6c4a641f24049a917db0cb": "DAI",
                "0xfde4c96c8593536e31f229ea8f37b2ada2699bb2": "USDT",
            },
        },
        "arbitrum": {
            "enabled": True,
            "chain_id": 42161,
            "gecko_network": "arbitrum",
            "alchemy_slug": "arb-mainnet",
            "gas_usd_per_swap": 0.15,
            "native_symbol": "ETH",
            "wrapped_native": "0x82af49447d8a07e3bd95bd0d56f35241523fbab1",
            "base_assets": {
                "0x82af49447d8a07e3bd95bd0d56f35241523fbab1": "WETH",
                "0xaf88d065e77c8cc2239327c5edb3a432268e5831": "USDC",
                "0xff970a61a04b1ca14834a43f5de4533ebddb5cc8": "USDC.e",
                "0xfd086bc7cd5c481dcc9c85ebe478a1c0b69fcbb9": "USDT",
                "0xda10009cbd5d07dd0cecc66161fc93d7c9000da1": "DAI",
            },
        },
    },
    "leaders": [],  # seed list: [{address, chain, label}]
    "validation": {
        "min_score": 60,
        "min_liquidity_usd": 75000,
        "max_cost_pct": 3.0,  # round-trip fees + slippage + gas as % of trade
        "dex_fee_pct": 0.3,  # per swap
        "max_delay_s": 90,
        "max_price_move_pct": 6.0,
        "max_plausible_gap_pct": 40.0,  # bigger gaps within seconds = bad price data, not a real move
        "min_token_age_h": 48,
        "max_top10_holder_pct": 50.0,
        "max_buy_tax_pct": 3.0,
        "max_sell_tax_pct": 3.0,
        "test_buy_ratio": 0.2,  # leader buy < 20% of their median size = test buy, skip
        "max_leader_recent_sells": 3,  # leader sold >= this many tokens in last hour = dumping
        "consensus_window_min": 60,
        "niche_penalty": 0.8,
        "token_denylist": [],
    },
    "risk": {
        "max_trade_pct": 10.0,
        "min_trade_usd": 15.0,
        "max_open_positions": 5,
        "max_per_asset_pct": 15.0,
        "max_per_leader_pct": 30.0,
        "max_per_chain_pct": 80.0,
        "daily_loss_limit_pct": 5.0,
        "weekly_loss_limit_pct": 12.0,
        "stop_loss_pct": 20.0,
        "take_profit_pct": 60.0,
        "max_hold_days": 14,
        "mirror_leader_sells": True,
        "allow_leverage": False,
    },
    "lifecycle": {
        "min_active_leaders": 5,
        "max_active_leaders": 15,
        "probation_days": 14,
        "probation_min_signals": 5,
        "promote_min_score": 60,
        "demote_score": 45,
        "demote_copy_loss_pct": 25.0,  # copy P&L on a leader's allocation over 30 days
        "discovery_interval_h": 24,
        "rescore_interval_h": 168,
        "max_candidates_scored_per_run": 12,
        "auto_activate_in_paper": True,  # paper mode: good new wallets trade on paper straight away
    },
    "discovery": {
        "min_pump_pct_24h": 15.0,
        "min_pool_liquidity_usd": 50000,
        "min_pool_age_h": 24,
        "max_winners": 8,
        "min_trade_usd": 100,
        "min_gain_pct": 15.0,  # wallet bought at least 15% below today's price
        "sniper_window_min": 10,
        "min_token_overlap": 1,
    },
    "scoring": {
        "history_days": 90,
        "min_closed_trades": 8,
        "bot_trades_per_day": 40,
        "bot_median_hold_s": 180,
        "one_hit_share": 0.7,
        "replay_trades": 10,
        "replay_delay_s": 30,
    },
    "improvement": {
        "enabled": True,
        "min_train_signals": 30,
        "min_test_signals": 10,
        "train_fraction": 0.7,
        "min_improvement_pct": 5.0,
        "trial_days": 14,
        "outcome_horizon_h": 24,
    },
    "alerts": {
        "telegram_enabled": True,
        "alert_rejected_min_score": 40,  # rejected signals scoring below this go only to the daily digest
        "daily_summary_hour_utc": 20,
    },
    "dashboard": {"host": "127.0.0.1", "port": 8787},
}

TUNABLE_PARAMS = {
    "validation.min_score": (5, 40, 90),
    "validation.max_price_move_pct": (2.0, 1.0, 20.0),
    "validation.min_liquidity_usd": (25000, 20000, 1000000),
    "validation.max_cost_pct": (0.5, 1.0, 6.0),
    "validation.min_token_age_h": (24, 0, 720),
}


def deep_merge(base: dict, override: dict) -> dict:
    out = copy.deepcopy(base)
    for k, v in (override or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = deep_merge(out[k], v)
        else:
            out[k] = copy.deepcopy(v)
    return out


def get_path(cfg: dict, dotted: str) -> Any:
    cur: Any = cfg
    for part in dotted.split("."):
        cur = cur[part]
    return cur


def set_path(cfg: dict, dotted: str, value: Any) -> dict:
    out = copy.deepcopy(cfg)
    cur = out
    parts = dotted.split(".")
    for part in parts[:-1]:
        cur = cur.setdefault(part, {})
    cur[parts[-1]] = value
    return out


def load_dotenv(path: str | Path = ".env") -> None:
    """Minimal .env loader so python-dotenv isn't required. Existing env wins."""
    p = Path(path)
    if not p.exists():
        return
    for line in p.read_text().splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))


@dataclass
class Secrets:
    alchemy_api_key: str = ""
    telegram_bot_token: str = ""
    telegram_chat_id: str = ""
    coingecko_api_key: str = ""
    wallet_private_key_set: bool = False  # we only record whether it exists

    @classmethod
    def from_env(cls) -> "Secrets":
        return cls(
            alchemy_api_key=os.environ.get("ALCHEMY_API_KEY", ""),
            telegram_bot_token=os.environ.get("TELEGRAM_BOT_TOKEN", ""),
            telegram_chat_id=os.environ.get("TELEGRAM_CHAT_ID", ""),
            coingecko_api_key=os.environ.get("COINGECKO_API_KEY", ""),
            wallet_private_key_set=bool(os.environ.get("WALLET_PRIVATE_KEY")),
        )


@dataclass
class Config:
    raw: dict = field(default_factory=lambda: copy.deepcopy(DEFAULTS))
    secrets: Secrets = field(default_factory=Secrets)

    def __getitem__(self, key: str) -> Any:
        return self.raw[key]

    def get(self, dotted: str) -> Any:
        return get_path(self.raw, dotted)

    @property
    def data_dir(self) -> Path:
        p = Path(self.raw["data_dir"])
        p.mkdir(parents=True, exist_ok=True)
        return p

    @property
    def is_live(self) -> bool:
        return self.raw["mode"] == "live" and bool(self.raw.get("allow_live"))

    def enabled_chains(self) -> dict[str, dict]:
        return {k: v for k, v in self.raw["chains"].items() if v.get("enabled")}

    def with_overrides(self, overrides: dict[str, Any]) -> "Config":
        raw = self.raw
        for k, v in overrides.items():
            raw = set_path(raw, k, v)
        return Config(raw=raw, secrets=self.secrets)


def load_config(path: str | Path = "config.yaml", env_path: str | Path = ".env") -> Config:
    load_dotenv(env_path)
    raw = copy.deepcopy(DEFAULTS)
    p = Path(path)
    if p.exists():
        user = yaml.safe_load(p.read_text()) or {}
        raw = deep_merge(raw, user)
    # lower-case all addresses once so comparisons are simple everywhere
    for chain in raw["chains"].values():
        chain["wrapped_native"] = chain["wrapped_native"].lower()
        chain["base_assets"] = {a.lower(): s for a, s in chain["base_assets"].items()}
    for leader in raw.get("leaders", []):
        leader["address"] = leader["address"].lower()
    raw["validation"]["token_denylist"] = [a.lower() for a in raw["validation"]["token_denylist"]]
    if os.environ.get("DASHBOARD_HOST"):  # set to 0.0.0.0 inside Docker; the host port stays on 127.0.0.1
        raw["dashboard"]["host"] = os.environ["DASHBOARD_HOST"]
    if raw["mode"] == "live" and not raw.get("allow_live"):
        raise SystemExit("mode is 'live' but allow_live is false. Refusing to start. See README go-live checklist.")
    return Config(raw=raw, secrets=Secrets.from_env())
