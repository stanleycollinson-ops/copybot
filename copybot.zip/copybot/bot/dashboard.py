"""Tiny read-only web dashboard (standard library only). Binds to 127.0.0.1 by default;
on a VPS, view it through an SSH tunnel rather than opening the port to the internet."""
from __future__ import annotations

import html
import json
import threading
import time
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from .report import performance

CSS = """
:root{--bg:#0f1115;--card:#171a21;--text:#e6e8ee;--muted:#9aa3b2;--line:#262b36;--good:#3fb950;--bad:#f85149;--acc:#7aa2f7}
@media (prefers-color-scheme: light){:root{--bg:#f6f7f9;--card:#fff;--text:#1d2129;--muted:#5d6675;--line:#e3e6eb;--good:#1a7f37;--bad:#cf222e;--acc:#3b5bdb}}
body{margin:0;background:var(--bg);color:var(--text);font:14px/1.45 -apple-system,system-ui,Segoe UI,Roboto,sans-serif}
main{max-width:1100px;margin:0 auto;padding:16px}
h1{font-size:20px;margin:4px 0 12px}h2{font-size:15px;margin:22px 0 8px;color:var(--muted);font-weight:600}
.tiles{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:10px}
.tile{background:var(--card);border:1px solid var(--line);border-radius:10px;padding:10px 12px}
.tile b{display:block;font-size:20px;font-variant-numeric:tabular-nums}.tile span{color:var(--muted);font-size:12px}
.wrap{overflow-x:auto;background:var(--card);border:1px solid var(--line);border-radius:10px}
table{border-collapse:collapse;width:100%;font-variant-numeric:tabular-nums}
th,td{padding:7px 10px;border-bottom:1px solid var(--line);text-align:left;white-space:nowrap}
th{color:var(--muted);font-weight:600;font-size:12px}
.good{color:var(--good)}.bad{color:var(--bad)}.muted{color:var(--muted)}
.pill{padding:1px 8px;border-radius:99px;border:1px solid var(--line);font-size:12px}
"""


def _fmt_ts(ts):
    return datetime.fromtimestamp(ts, tz=timezone.utc).strftime("%d %b %H:%M") if ts else ""


def _cls(v):
    return "good" if (v or 0) >= 0 else "bad"


def _table(headers, rows):
    head = "".join(f"<th>{html.escape(h)}</th>" for h in headers)
    body = "".join("<tr>" + "".join(f"<td>{c}</td>" for c in r) + "</tr>" for r in rows) or \
        f"<tr><td class=muted colspan={len(headers)}>Nothing yet</td></tr>"
    return f"<div class=wrap><table><thead><tr>{head}</tr></thead><tbody>{body}</tbody></table></div>"


def render(db) -> str:
    mode = "paper"
    p = performance(db, mode)
    paused = "kill switch ON" if db.kv_get("kill") else "running"
    tiles = [
        (f"${p['equity_usd']:.2f}", "Equity (USD)"),
        (f"<span class={_cls(p['return_pct'])}>{p['return_pct']:+.1f}%</span>", "Return after costs"),
        (f"{p['closed_trades']}", "Closed trades"),
        (f"{p['win_rate'] * 100:.0f}%", "Win rate"),
        (f"{p['avg_entry_vs_leader_pct']:+.1f}%" if p['avg_entry_vs_leader_pct'] is not None else "–", "Entry vs leader"),
        (f"{p['avg_delay_s']:.0f}s" if p['avg_delay_s'] is not None else "–", "Avg copy delay"),
        (f"${p['fees_usd']:.2f}", "Fees + gas"),
        (paused, "Status"),
    ]
    tiles_html = "".join(f"<div class=tile><b>{v}</b><span>{k}</span></div>" for v, k in tiles)

    pos = []
    for r in db.q("SELECT * FROM positions WHERE status='open' ORDER BY opened_ts DESC"):
        val = r["qty"] * (r["last_price"] or r["entry_price"])
        pnl = val - r["cost_usd"]
        pos.append([html.escape(r["symbol"] or ""), r["chain"], html.escape((r["leader"] or "")[:10]),
                    f"${r['cost_usd']:.2f}", f"${val:.2f}", f"<span class={_cls(pnl)}>{pnl:+.2f}</span>",
                    _fmt_ts(r["opened_ts"])])
    leaders = []
    for r in db.q("SELECT * FROM leaders WHERE status!='retired' ORDER BY status='active' DESC, score DESC LIMIT 40"):
        m = json.loads(r["metrics"]) if r["metrics"] else {}
        cp = m.get("copy_return_pct")
        leaders.append([html.escape(r["label"] or r["address"][:12]), r["chain"], f"<span class=pill>{r['status']}</span>",
                        f"{r['score'] or 0:.0f}", f"{m.get('win_rate', 0) * 100:.0f}%", f"{m.get('profit_factor', 0):.2f}",
                        f"{cp:+.1f}%" if cp is not None else "–", html.escape(", ".join(m.get("flags", [])))])
    sigs = []
    for r in db.q("SELECT * FROM signals ORDER BY ts DESC LIMIT 40"):
        reasons = ", ".join(json.loads(r["reasons"] or "[]"))
        sigs.append([_fmt_ts(r["ts"]), html.escape(r["symbol"] or ""), r["mode"], f"{r['score'] or 0:.0f}",
                     "<span class=good>approved</span>" if r["approved"] else "<span class=bad>rejected</span>",
                     html.escape(reasons[:90])])
    closed = []
    for r in db.q("SELECT * FROM positions WHERE status='closed' ORDER BY closed_ts DESC LIMIT 25"):
        closed.append([_fmt_ts(r["closed_ts"]), html.escape(r["symbol"] or ""), html.escape(r["exit_reason"] or ""),
                       f"<span class={_cls(r['realised_pnl_usd'])}>{r['realised_pnl_usd'] or 0:+.2f}</span>"])
    props = [[r["id"], r["param"], f"{r['current_value']} → {r['proposed_value']}", r["status"]]
             for r in db.q("SELECT * FROM proposals ORDER BY id DESC LIMIT 10")]
    return f"""<!doctype html><html><head><meta charset=utf-8><meta name=viewport content="width=device-width,initial-scale=1">
<meta http-equiv=refresh content=30><title>CopyBot</title><style>{CSS}</style></head><body><main>
<h1>CopyBot <span class=muted>· {mode} mode · {datetime.now(timezone.utc).strftime('%H:%M UTC')}</span></h1>
<div class=tiles>{tiles_html}</div>
<h2>Open positions</h2>{_table(['Token','Chain','Leader','Cost','Value','P&L $','Opened'], pos)}
<h2>Leaders</h2>{_table(['Leader','Chain','Status','Score','Win rate','Profit factor','Copy return','Flags'], leaders)}
<h2>Recent signals</h2>{_table(['Time','Token','Mode','Score','Decision','Reasons'], sigs)}
<h2>Closed trades</h2>{_table(['Closed','Token','Exit','P&L $'], closed)}
<h2>Strategy proposals</h2>{_table(['#','Parameter','Change','Status'], props)}
</main></body></html>"""


def start_dashboard(db, host: str, port: int) -> None:
    class H(BaseHTTPRequestHandler):
        def do_GET(self):  # noqa: N802
            try:
                body = render(db).encode()
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
            except Exception as e:  # never crash the bot over the dashboard
                body = f"dashboard error: {e}".encode()
                self.send_response(500)
            self.end_headers()
            self.wfile.write(body)

        def log_message(self, *a):
            pass

    try:
        srv = ThreadingHTTPServer((host, port), H)
    except OSError:
        return
    threading.Thread(target=srv.serve_forever, daemon=True).start()
