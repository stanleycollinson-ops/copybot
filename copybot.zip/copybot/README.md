# CopyBot: multi-leader on-chain copy-trading bot

CopyBot watches a pool of profitable wallets ("leaders") on **Base** and **Arbitrum**. It checks every token they buy against safety, cost and timing rules, then copies only the trades that pass. It mirrors their sells, adds its own stop-loss and take-profit, finds new leaders every day, retires weak ones, and proposes rule changes it has tested.

**It starts in paper mode**: simulated money, real market data. Live trading is deliberately switched off until the go-live checklist at the bottom passes.

> Be realistic: most copy-trading loses money once you count delay, slippage and fees. This bot measures exactly that. If paper results after costs are negative, the right move is to not go live.

---

## How it decides

```
leader wallet swaps ──► watcher (live, via Alchemy) ──► signal
                                                          │
            token safety (GoPlus) · liquidity · cost · delay · price move · leader context
                                                          │  any hard fail → rejected (logged + reason)
                                                          ▼
                     score 0-100: leader quality · conviction · consensus · BTC trend · momentum · safety
                                                          │  below min_score → rejected
                                                          ▼
                 risk engine: size by score, caps per trade/token/leader/chain, loss limits, kill switch
                                                          ▼
                        paper buy  ──►  exits: leader sells · stop-loss · take-profit · max hold
```

**Leader lifecycle:** discovered or added → **probation** (signals tracked in shadow mode, no money) → **active** (gets trades) → demoted or **retired** if copy results go bad.

**Self-improvement (never silent):** every signal's price is recorded 1h and 24h later, including rejected ones. Each week the bot reports which filters saved money and which skipped winners. It *proposes* a threshold change only if the change wins on older data **and** on newer data it wasn't tuned on. You start a trial, and you promote it only if the trial wins too.

---

## Setup (about 30 minutes)

### 1. Install Python

- **Mac:** install Python 3.12 from https://www.python.org/downloads/ and open the **Terminal** app.
- **Windows:** install Python 3.12 from the same page. Tick **"Add python.exe to PATH"** during install, then open **PowerShell**.

Check it worked with `python3 --version`. On Windows, type `python` instead of `python3` everywhere below.

### 2. Get the code and install it

Put the `copybot` folder somewhere easy, e.g. your Documents folder. Then run:

```bash
cd ~/Documents/copybot          # Windows: cd $HOME\Documents\copybot
python3 -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

You'll see `(.venv)` at the start of the line. Run the `activate` line again each time you open a new terminal.

### 3. Alchemy key (free, needed for blockchain data)

1. Sign up at https://dashboard.alchemy.com
2. Create an app and enable **Base Mainnet** and **Arbitrum Mainnet** on it.
3. Copy the **API key**.

### 4. Telegram alerts (recommended)

1. In Telegram, message **@BotFather**, send `/newbot`, and follow the prompts. Copy the **token** it gives you.
2. Send any message to your new bot.
3. Open `https://api.telegram.org/bot<YOUR_TOKEN>/getUpdates` in a browser. The number after `"chat":{"id":` is your **chat id**.

### 5. Fill in your settings

```bash
cp .env.example .env
cp config.example.yaml config.yaml
```

Windows: use `copy` instead of `cp`.

Open `.env` in a text editor and paste your Alchemy key, Telegram token and chat id. `config.yaml` already has sensible defaults for £200.

### 6. Test everything

```bash
python3 -m bot.cli check
```

Every line should say `[ok]`, and you should get a Telegram test message.

### 7. Add some leaders

The bot finds wallets by itself every day. To start faster, find wallets yourself:

- **DexScreener:** open a Base or Arbitrum token that has done well, then open the **Top Traders** tab.
- **GMGN, Arkham, Nansen:** look up profitable wallets on Base or Arbitrum.

Then score each wallet and backtest copying it:

```bash
python3 -m bot.cli score  0xWALLET base
python3 -m bot.cli replay 0xWALLET base --delay 30
python3 -m bot.cli add-leader 0xWALLET base -l "my-label"
```

Look for three things before adding a wallet:

- a score above 60
- no flags
- a **positive copy return** in the replay. That figure includes your delay, slippage and gas.

### 8. Run it

```bash
python3 -m bot.cli run
```

Open the dashboard at **http://127.0.0.1:8787**. It refreshes every 30 seconds. To stop the bot, press `Ctrl+C`.

---

## Moving to a VPS (before going live, or once you want it running 24/7)

A laptop is fine for the first days of paper testing. For 24/7 running, rent the smallest Ubuntu server (a few pounds a month) from Hetzner, DigitalOcean or similar.

```bash
# on the server
sudo apt update && sudo apt install -y docker.io docker-compose-v2
# from your laptop: copy the folder up (including .env and config.yaml)
scp -r ~/Documents/copybot root@SERVER_IP:/root/
# on the server
cd /root/copybot && sudo docker compose up -d --build
sudo docker compose logs -f        # watch it start; Ctrl+C stops watching, not the bot
```

It restarts automatically after crashes and reboots. To view the dashboard securely, run this on your laptop, then open http://127.0.0.1:8787:

```bash
ssh -L 8787:127.0.0.1:8787 root@SERVER_IP
```

Run commands on the server like this: `sudo docker compose exec copybot python -m bot.cli report`

---

## Commands

| Command | What it does |
|---|---|
| `run` | Start the bot |
| `check` | Test keys and data sources |
| `score ADDR CHAIN` | Score a wallet (P&L, win rate, drawdown, bot/sniper/one-hit flags, copy return) |
| `replay ADDR CHAIN --delay 30` | Backtest copying its last 20 buys with your delay, slippage and gas |
| `add-leader ADDR CHAIN -l NAME` | Add on probation (`--activate` skips probation; not recommended) |
| `discover [CHAIN]` | Run leader discovery now |
| `leaders` | List all leaders and their status |
| `report` | Performance so far + go-live checklist |
| `proposals` / `trial ID` / `promote ID` / `reject ID` | Strategy-improvement workflow |
| `export-tax --mode live` | HMRC-ready trade ledger + CGT disposals CSV in `data/tax/` |
| `kill` / `resume` | Emergency stop for new trades (open positions keep their stop-losses) |
| `close-all` | Close every paper position now |

## Your routine

- **Daily (2 min):** read the 20:00 UTC Telegram summary.
- **Weekly (10 min):** read the weekly strategy review. Check `leaders` for new probation wallets. Use `trial`/`promote` only when the numbers support it.
- **Anything odd:** run `python3 -m bot.cli kill` first, investigate second.

## Tuning without the improvement workflow

Edit `config.yaml` and restart. The settings that matter most:

- `min_score`: higher means fewer, better trades.
- `max_price_move_pct`: how late you're willing to chase a leader's entry.
- `max_cost_pct`: the cost ceiling per trade.
- `max_trade_pct`: how much of the account each trade can use.

---

## Go-live checklist

Live execution is **not included yet** on purpose. Ask for the live module only when **all** of these are true:

- [ ] `report` shows **14+ days** of paper trading (28 is better) and **15+ closed trades**
- [ ] Paper return **after all costs is positive**
- [ ] Average "entry vs leader" is small enough that winners still win (watch the dashboard tile)
- [ ] At least 3 leaders are **active** after passing probation
- [ ] You've created a **brand-new wallet** used only for this, funded with only what you can afford to lose
- [ ] Bot running on a VPS, Telegram alerts working, and you've tested `kill`

The live module will swap through a DEX aggregator. Every swap is simulated first, approvals are for exact amounts, and each trade has a hard minimum output. It will also need `mode: live` **and** `allow_live: true`. Set just one and the bot refuses to start.

## Safety notes

- Keys live only in `.env`. They're never in code, the database or logs.
- The dashboard is only reachable from your own machine.
- Spot only. There is no leverage code.
- UK tax: every sale or swap is a disposal for CGT. Run `export-tax` before each tax return. The figures are estimates for your tax software or accountant.

See `FEASIBILITY.md` for why eToro, Involio, Bitget/Bybit and Hyperliquid aren't wired in.

## Developer notes

- Tests: `python3 -m unittest discover -s tests -t .` (offline, no keys needed)
- Code map: `bot/engine.py` (runtime), `validator.py`, `risk.py`, `scoring.py`, `history.py` (wallet history + replay), `lifecycle.py` (discovery/promotion), `improve.py`, `tax.py`, `dashboard.py`, `cli.py`
