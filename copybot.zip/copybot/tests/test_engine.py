"""End-to-end run of the engine with faked market data and RPC: signal -> validate -> paper buy ->
leader sell mirrored -> dashboard -> tax export. No network."""
import asyncio
import json
import os
import tempfile
import time
import unittest
from pathlib import Path

from bot.config import load_config
from bot.dashboard import render
from bot.db import DB
from bot.engine import Engine
from bot.models import LeaderTrade
from bot.tax import export

LEADER = "0x1111111111111111111111111111111111111111"
TOKEN = "0x3333333333333333333333333333333333333333"


class FakeMarket:
    price = 1.0

    async def token_pool(self, network, token):
        return {"pool": "0xpool", "price_usd": self.price, "liquidity_usd": 600_000, "volume_24h_usd": 900_000,
                "price_change_h1": 1.5, "price_change_h24": 10, "age_h": 500, "created_ts": 0, "token_is_base": True}

    async def token_security(self, chain_id, token):
        return dict(is_honeypot=False, cannot_sell_all=False, buy_tax_pct=0.0, sell_tax_pct=0.0, is_open_source=True,
                    is_mintable=False, owner_change_balance=False, transfer_pausable=False, slippage_modifiable=False,
                    is_blacklisted=False, hidden_owner=False, lp_locked_pct=99.0, top10_holder_pct=10.0)

    async def btc_risk_on(self):
        return True

    async def gbp_per_usd(self):
        return 0.75

    async def eth_usd(self):
        return 2500.0

    async def token_prices(self, network, tokens):
        return {t: self.price for t in tokens}


class FakeRPC:
    async def symbol(self, token):
        return "TKN"

    async def balance_of(self, token, owner, block="latest"):
        return 0  # leader sold everything

    async def decimals(self, token):
        return 18


class TestEngine(unittest.TestCase):
    def test_full_flow(self):
        with tempfile.TemporaryDirectory() as d:
            cfgp = Path(d) / "config.yaml"
            cfgp.write_text(f"data_dir: {d}/data\nalerts:\n  telegram_enabled: false\n")
            os.environ["ALCHEMY_API_KEY"] = "test"
            cfg = load_config(cfgp, Path(d) / ".env")
            db = DB(cfg.data_dir / "copybot.sqlite")
            eng = Engine(cfg, db)
            fm = FakeMarket()
            eng.market = fm
            eng.bg_market = fm
            eng.rpcs = {"base": FakeRPC(), "arbitrum": FakeRPC()}
            db.upsert_leader(LEADER, "base", label="whale1", status="active", score=80, median_trade_usd=1000)

            async def flow():
                now = time.time()
                buy = LeaderTrade("base", LEADER, "0xaa", 1, now - 15, "buy", TOKEN, 1000, 990)
                db.add_leader_trade(buy)
                await eng.handle_buy(buy)
                pos = db.q("SELECT * FROM positions WHERE status='open'")
                self.assertEqual(len(pos), 1, db.q("SELECT reasons FROM signals")[0]["reasons"])
                self.assertGreater(pos[0]["cost_usd"], 15)

                # probation leader's signal is shadow-only
                other = "0x5555555555555555555555555555555555555555"
                db.upsert_leader(other, "base", status="probation", score=70)
                b2 = LeaderTrade("base", other, "0xbb", 2, now - 10, "buy", TOKEN, 500, 495)
                db.add_leader_trade(b2)
                await eng.handle_buy(b2)
                sig = db.one("SELECT * FROM signals WHERE leader=?", (other,))
                self.assertEqual(sig["mode"], "shadow")
                self.assertEqual(json.loads(sig["snapshot"])["consensus_independent"], 2)
                self.assertEqual(len(db.q("SELECT * FROM positions")), 1)

                # leader sells -> we sell
                fm.price = 1.25
                sell = LeaderTrade("base", LEADER, "0xcc", 3, now, "sell", TOKEN, 1000, 1250)
                await eng.handle_leader_sell(sell)
                p = db.one("SELECT * FROM positions WHERE id=?", (pos[0]["id"],))
                self.assertEqual(p["status"], "closed")
                self.assertGreater(p["realised_pnl_usd"], 0)

                # kill switch blocks new entries
                db.kv_set("kill", True)
                eng.pause_reason = eng.guard.check(eng.exposure().equity_usd)
                b3 = LeaderTrade("base", LEADER, "0xdd", 4, time.time(), "buy", TOKEN, 1000, 1250)
                db.add_leader_trade(b3)
                await eng.handle_buy(b3)
                self.assertEqual(len(db.q("SELECT * FROM positions")), 1)

            asyncio.run(flow())
            html = render(db)
            self.assertIn("whale1", html)
            self.assertIn("TKN", html)
            ledger, cgt, totals = export(db, Path(d) / "tax", "paper")
            self.assertTrue(ledger.exists() and cgt.exists())
            self.assertEqual(len(totals), 1)
            self.assertGreater(list(totals.values())[0], 0)


if __name__ == "__main__":
    unittest.main()


class TestTxDecoding(unittest.TestCase):
    def test_handle_tx_builds_buy_from_receipt(self):
        from bot.parse import TRANSFER_TOPIC, address_to_topic
        POOL = "0x2222222222222222222222222222222222222222"
        WETH = "0x4200000000000000000000000000000000000006"

        class RPC(FakeRPC):
            async def call(self, method, params):
                if method == "eth_getTransactionByHash":
                    return {"from": LEADER, "value": "0x0"}
                if method == "eth_getTransactionReceipt":
                    return {"status": "0x1", "blockNumber": "0x64", "logs": [
                        {"address": WETH, "topics": [TRANSFER_TOPIC, address_to_topic(LEADER), address_to_topic(POOL)],
                         "data": hex(2 * 10**17), "logIndex": "0x1"},
                        {"address": TOKEN, "topics": [TRANSFER_TOPIC, address_to_topic(POOL), address_to_topic(LEADER)],
                         "data": hex(1000 * 10**18), "logIndex": "0x2"}]}

            async def block_ts(self, b):
                return time.time() - 5

            async def native_received_in_tx(self, owner, receipt):
                return 0.0

        with tempfile.TemporaryDirectory() as d:
            cfgp = Path(d) / "config.yaml"
            cfgp.write_text(f"data_dir: {d}/data\nalerts:\n  telegram_enabled: false\n")
            os.environ["ALCHEMY_API_KEY"] = "test"
            cfg = load_config(cfgp, Path(d) / ".env")
            db = DB(cfg.data_dir / "copybot.sqlite")
            eng = Engine(cfg, db)
            eng.market = FakeMarket()
            db.upsert_leader(LEADER, "base", status="active", score=80)

            async def go():
                await eng._handle_tx("base", RPC(), "0xhash")
                t = eng.queue.get_nowait()
                self.assertEqual((t.side, t.token, t.token_amount), ("buy", TOKEN, 1000.0))
                self.assertAlmostEqual(t.quote_usd, 500.0)  # 0.2 WETH x $2500
                await eng._handle_tx("base", RPC(), "0xhash")  # duplicate is ignored
                self.assertTrue(eng.queue.empty())
            asyncio.run(go())
