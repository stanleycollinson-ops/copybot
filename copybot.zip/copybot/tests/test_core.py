"""Offline tests for the pure logic (no network, no API keys). Run: python -m unittest -v"""
import json
import tempfile
import time
import unittest
from datetime import datetime, timezone
from pathlib import Path

from bot.config import DEFAULTS, Config, deep_merge, load_config, set_path
from bot.db import DB
from bot.executor import PaperExecutor
from bot.improve import evaluate, filter_report, propose
from bot.models import LeaderTrade, Snapshot, TokenTransfer
from bot.parse import (TRANSFER_TOPIC, address_to_topic, build_trades, decode_transfer_log,
                       group_asset_transfers)
from bot.risk import Exposure, RiskGuard, size_trade
from bot.scoring import compute_metrics, round_trips
from bot.tax import match_disposals, tax_year
from bot.validator import estimate_cost_pct, validate

LEADER = "0x1111111111111111111111111111111111111111"
POOL = "0x2222222222222222222222222222222222222222"
TOKEN = "0x3333333333333333333333333333333333333333"
WETH = "0x4200000000000000000000000000000000000006"
USDC = "0x833589fcd6edb6e08f4c7c32d4f71b54bda02913"
BASE = {k.lower(): v for k, v in DEFAULTS["chains"]["base"]["base_assets"].items()}
VCFG = DEFAULTS["validation"]
RCFG = DEFAULTS["risk"]


def good_snapshot(**kw) -> Snapshot:
    s = Snapshot(chain="base", token=TOKEN, symbol="TKN", leader=LEADER, leader_score=75,
                 leader_median_trade_usd=1000, leader_trade_usd=1500, leader_price=1.0, delay_s=20,
                 current_price=1.02, liquidity_usd=500_000, volume_24h_usd=800_000, price_change_h1=2,
                 token_age_h=400, is_honeypot=False, cannot_sell_all=False, buy_tax_pct=0, sell_tax_pct=0,
                 is_open_source=True, owner_change_balance=False, transfer_pausable=False,
                 slippage_modifiable=False, is_blacklisted=False, hidden_owner=False, lp_locked_pct=95,
                 top10_holder_pct=12, btc_risk_on=True, consensus_independent=2, trade_size_usd=25,
                 gas_usd_per_swap=0.05)
    for k, v in kw.items():
        setattr(s, k, v)
    return s


class TestParse(unittest.TestCase):
    def test_decode_transfer(self):
        log = {"address": TOKEN.upper().replace("X", "x"), "topics": [TRANSFER_TOPIC, address_to_topic(POOL),
               address_to_topic(LEADER)], "data": hex(5 * 10**18), "logIndex": "0x3"}
        t = decode_transfer_log(log, 18)
        self.assertEqual((t.token, t.frm, t.to, t.amount, t.log_index), (TOKEN, POOL, LEADER, 5.0, 3))

    def test_nft_transfer_ignored(self):
        log = {"address": TOKEN, "topics": [TRANSFER_TOPIC, "0x0", "0x0", "0x1"], "data": "0x"}
        self.assertIsNone(decode_transfer_log(log, 0))

    def test_buy_with_usdc(self):
        tr = [TokenTransfer(USDC, LEADER, POOL, 200), TokenTransfer(TOKEN, POOL, LEADER, 100)]
        (t,) = build_trades(chain="base", leader=LEADER, tx_hash="0xa", block=1, ts=1, transfers=tr,
                            base_assets=BASE, eth_usd=3000)
        self.assertEqual((t.side, t.token, t.token_amount, t.quote_usd), ("buy", TOKEN, 100, 200))
        self.assertAlmostEqual(t.price_usd, 2.0)

    def test_buy_with_native_eth(self):
        tr = [TokenTransfer(TOKEN, POOL, LEADER, 50)]
        (t,) = build_trades(chain="base", leader=LEADER, tx_hash="0xa", block=1, ts=1, transfers=tr,
                            base_assets=BASE, eth_usd=2000, native_sent=0.1)
        self.assertEqual(t.quote_usd, 200)

    def test_sell_for_weth_and_token_swap(self):
        tr = [TokenTransfer(TOKEN, LEADER, POOL, 10), TokenTransfer(WETH, POOL, LEADER, 0.5)]
        (t,) = build_trades(chain="base", leader=LEADER, tx_hash="0xa", block=1, ts=1, transfers=tr,
                            base_assets=BASE, eth_usd=2000)
        self.assertEqual((t.side, t.quote_usd), ("sell", 1000))
        other = "0x4444444444444444444444444444444444444444"
        tr = [TokenTransfer(TOKEN, LEADER, POOL, 10), TokenTransfer(other, POOL, LEADER, 3)]
        sides = sorted(x.side for x in build_trades(chain="base", leader=LEADER, tx_hash="0xb", block=1, ts=1,
                                                     transfers=tr, base_assets=BASE, eth_usd=2000))
        self.assertEqual(sides, ["buy", "sell"])

    def test_plain_transfer_in_is_not_a_trade_signal_source(self):
        rows = [{"hash": "0xh", "blockNum": "0x10", "from": POOL, "to": LEADER, "value": 5, "category": "erc20",
                 "rawContract": {"address": TOKEN}, "metadata": {"blockTimestamp": "2026-10-01T00:00:00Z"}}]
        g = group_asset_transfers(rows, LEADER)
        self.assertFalse(g["0xh"]["leader_initiated"])  # airdrop/spam: leader didn't send anything


class TestValidator(unittest.TestCase):
    def test_good_signal_approved(self):
        d = validate(good_snapshot(), VCFG)
        self.assertTrue(d.approved, d.reasons)
        self.assertGreaterEqual(d.score, VCFG["min_score"])

    def test_hard_fails(self):
        cases = {
            "honeypot": dict(is_honeypot=True),
            "sell tax": dict(sell_tax_pct=10),
            "liquidity": dict(liquidity_usd=10_000),
            "price already up": dict(current_price=1.2),
            "old": dict(delay_s=600),
            "too new": dict(token_age_h=3),
            "test buy": dict(leader_trade_usd=50),
            "top-10": dict(top10_holder_pct=80),
            "no safety data": dict(is_honeypot=None, is_open_source=None),
            "leader sold": dict(leader_recent_sells_1h=5),
        }
        for want, kw in cases.items():
            d = validate(good_snapshot(**kw), VCFG)
            self.assertFalse(d.approved, want)
            self.assertTrue(any(want in r for r in d.reasons), (want, d.reasons))

    def test_cost_gate_hits_small_trades(self):
        # $5 trade on Arbitrum-style gas: gas alone is 6% round trip
        d = validate(good_snapshot(trade_size_usd=5, gas_usd_per_swap=0.15), VCFG)
        self.assertTrue(any("cost" in r for r in d.reasons))
        self.assertAlmostEqual(estimate_cost_pct(100, 1_000_000, 0.3, 0.05), 2 * (0.3 + 0.02) + 0.1, places=6)

    def test_consensus_raises_score(self):
        one = validate(good_snapshot(consensus_independent=1), VCFG).score
        three = validate(good_snapshot(consensus_independent=3), VCFG).score
        self.assertGreater(three, one)


class TestRisk(unittest.TestCase):
    def exp(self, **kw):
        base = dict(equity_usd=260, cash_usd=260, open_positions=0, by_asset={}, by_leader={}, by_chain={})
        base.update(kw)
        return Exposure(**base)

    def test_size_scales_with_score(self):
        lo, _ = size_trade(rcfg=RCFG, exp=self.exp(), chain="base", token=TOKEN, leader=LEADER, score=60,
                           min_score=60, leader_weight=1)
        hi, _ = size_trade(rcfg=RCFG, exp=self.exp(), chain="base", token=TOKEN, leader=LEADER, score=100,
                           min_score=60, leader_weight=1)
        self.assertAlmostEqual(lo, 15.6)  # 60% of the $26 per-trade cap at the threshold score
        self.assertAlmostEqual(hi, 26.0)   # full cap at a perfect score

    def test_caps(self):
        size, why = size_trade(rcfg=RCFG, exp=self.exp(open_positions=5), chain="base", token=TOKEN,
                               leader=LEADER, score=90, min_score=60, leader_weight=1)
        self.assertEqual(size, 0)
        size, why = size_trade(rcfg=RCFG, exp=self.exp(by_asset={f"base:{TOKEN}": 30}), chain="base",
                               token=TOKEN, leader=LEADER, score=95, min_score=60, leader_weight=1.5)
        self.assertEqual(size, 0)
        self.assertIn("asset cap", why)

    def test_loss_limits_and_kill(self):
        with tempfile.TemporaryDirectory() as d:
            db = DB(Path(d) / "t.sqlite")
            g = RiskGuard(db, RCFG, Path(d))
            now = datetime(2026, 10, 14, 9, tzinfo=timezone.utc).timestamp()
            self.assertIsNone(g.check(260, now))
            self.assertIsNone(g.check(250, now + 60))
            self.assertIn("daily loss", g.check(245, now + 120))
            self.assertIsNone(g.check(245, now + 86400))  # new day resets
            db.kv_set("kill", True)
            self.assertIn("kill", g.check(300, now + 86400))


def trade(side, ts, qty, usd, token=TOKEN):
    return LeaderTrade("base", LEADER, f"0x{ts}", 1, ts, side, token, qty, usd)


class TestScoring(unittest.TestCase):
    SCFG = dict(DEFAULTS["scoring"], sniper_window_s=600)

    def test_fifo_round_trips(self):
        rts = round_trips([trade("buy", 0, 10, 100), trade("buy", 10, 10, 200), trade("sell", 20, 15, 300)])
        self.assertEqual(len(rts), 2)
        self.assertAlmostEqual(sum(r.pnl for r in rts), 300 - (100 + 100))

    def test_good_trader_scores_well(self):
        day = 86400
        now = 100 * day
        ts = []
        for i in range(12):
            tok = f"0x{i:040x}"
            win = i % 3 != 0
            ts += [trade("buy", now - (60 - i * 4) * day, 100, 1000, tok),
                   trade("sell", now - (60 - i * 4) * day + 2 * day, 100, 1600 if win else 800, tok)]
        m = compute_metrics(ts, self.SCFG, now)
        self.assertFalse(m.flags, m.flags)
        self.assertGreater(m.score, 60)

    def test_bot_and_one_hit_flags(self):
        now = 10 * 86400
        bot = []
        for i in range(30):
            bot += [trade("buy", now - 1000 + i * 10, 1, 100, f"0x{i:040x}"),
                    trade("sell", now - 1000 + i * 10 + 5, 1, 101, f"0x{i:040x}")]
        self.assertIn("bot/MEV-like activity", compute_metrics(bot, self.SCFG, now).flags)
        one = [trade("buy", 0, 1, 100, "0xa"), trade("sell", 86400, 1, 10000, "0xa")]
        for i in range(8):
            one += [trade("buy", 86400 * (i + 2), 1, 100, f"0x{i}"), trade("sell", 86400 * (i + 3), 1, 105, f"0x{i}")]
        self.assertIn("one-hit wonder", compute_metrics(one, self.SCFG, 20 * 86400).flags)


class TestPaperAndTax(unittest.TestCase):
    def test_paper_round_trip_costs_money_when_flat(self):
        with tempfile.TemporaryDirectory() as d:
            db = DB(Path(d) / "t.sqlite")
            ex = PaperExecutor(db, 0.3, 260.0)
            pid = ex.buy(chain="base", token=TOKEN, symbol="TKN", leader=LEADER, signal_id=1, size_usd=25,
                         price=1.0, liquidity_usd=500_000, gas_usd=0.05, leader_price=0.99, delay_s=12,
                         gbp_per_usd=0.75)
            self.assertAlmostEqual(ex.cash, 260 - 25.05)
            pnl = ex.sell(position_id=pid, fraction=0.5, price=1.0, liquidity_usd=500_000, gas_usd=0.05,
                          reason="test", gbp_per_usd=0.75)
            self.assertLess(pnl, 0)
            pnl2 = ex.sell(position_id=pid, fraction=1.0, price=1.0, liquidity_usd=500_000, gas_usd=0.05,
                           reason="test", gbp_per_usd=0.75)
            p = db.one("SELECT * FROM positions WHERE id=?", (pid,))
            self.assertEqual(p["status"], "closed")
            self.assertAlmostEqual(p["realised_pnl_usd"], pnl + pnl2, places=9)
            self.assertAlmostEqual(ex.cash, 260 + pnl + pnl2, places=9)  # cash reconciles with P&L

    def test_uk_matching_rules(self):
        d = lambda y, m, dd: datetime(y, m, dd, 12, tzinfo=timezone.utc).timestamp()
        fills = [
            {"ts": d(2026, 5, 1), "asset": "X", "side": "buy", "qty": 100, "gbp_value": 100, "gbp_fee": 0},
            {"ts": d(2026, 6, 1), "asset": "X", "side": "sell", "qty": 50, "gbp_value": 150, "gbp_fee": 0},
            {"ts": d(2026, 6, 10), "asset": "X", "side": "buy", "qty": 50, "gbp_value": 120, "gbp_fee": 0},
            {"ts": d(2026, 7, 1), "asset": "X", "side": "buy", "qty": 10, "gbp_value": 30, "gbp_fee": 0},
            {"ts": d(2026, 7, 1), "asset": "X", "side": "sell", "qty": 10, "gbp_value": 40, "gbp_fee": 1},
        ]
        rows = match_disposals(fills)
        june, july = rows
        self.assertEqual(june["rules"], "30-day")  # matched to the 10 June re-buy, not the pool
        self.assertAlmostEqual(june["gain_gbp"], 30)
        self.assertEqual(july["rules"], "same-day")
        self.assertAlmostEqual(july["gain_gbp"], 9)
        self.assertEqual(tax_year(datetime(2026, 4, 5).date()), "2025/26")
        self.assertEqual(tax_year(datetime(2026, 4, 6).date()), "2026/27")

    def test_s104_pool(self):
        d = lambda m: datetime(2026, m, 1, tzinfo=timezone.utc).timestamp()
        fills = [{"ts": d(5), "asset": "Y", "side": "buy", "qty": 10, "gbp_value": 100, "gbp_fee": 0},
                 {"ts": d(6), "asset": "Y", "side": "buy", "qty": 10, "gbp_value": 300, "gbp_fee": 0},
                 {"ts": d(9), "asset": "Y", "side": "sell", "qty": 5, "gbp_value": 150, "gbp_fee": 0}]
        (row,) = match_disposals(fills)
        self.assertEqual(row["rules"], "s104")
        self.assertAlmostEqual(row["cost_gbp"], 100)  # average cost £20 x 5


class TestImprove(unittest.TestCase):
    def test_proposes_only_when_train_and_test_agree(self):
        # Signals rejected only for "price already up 7-8%" kept rising afterwards, so loosening
        # max_price_move_pct from 6 to 8 should be proposed.
        outs = []
        for i in range(60):
            moved = i % 2 == 0
            snap = good_snapshot(current_price=1.07 if moved else 1.01)
            outs.append({"ts": i, "snap": snap, "ret_pct": 12.0 if moved else 1.0, "approved": not moved,
                         "trial_approved": None, "trial_proposal_id": None})
        raw = json.loads(json.dumps(DEFAULTS))
        props = propose(outs, raw, DEFAULTS["improvement"])
        params = {p["param"]: p for p in props}
        self.assertIn("validation.max_price_move_pct", params)
        self.assertEqual(params["validation.max_price_move_pct"]["proposed"], 8.0)
        lines = filter_report(outs, DEFAULTS["validation"])
        self.assertTrue(any("skipped winners" in l for l in lines))

    def test_no_proposal_on_noise(self):
        outs = [{"ts": i, "snap": good_snapshot(current_price=1.07 if i % 2 else 1.01),
                 "ret_pct": (5 if i < 42 else -20) if i % 2 else 1.0, "approved": not i % 2,
                 "trial_approved": None, "trial_proposal_id": None} for i in range(60)]
        props = propose(outs, json.loads(json.dumps(DEFAULTS)), DEFAULTS["improvement"])
        self.assertNotIn("validation.max_price_move_pct", {p["param"] for p in props})  # fails out-of-sample


class TestConfig(unittest.TestCase):
    def test_live_refused_without_flag(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / "c.yaml"
            p.write_text("mode: live\n")
            with self.assertRaises(SystemExit):
                load_config(p, Path(d) / ".env")
            p.write_text("mode: paper\ncapital_gbp: 300\nleaders:\n  - {address: '0xABC', chain: base}\n")
            cfg = load_config(p, Path(d) / ".env")
            self.assertFalse(cfg.is_live)
            self.assertEqual(cfg["capital_gbp"], 300)
            self.assertEqual(cfg["leaders"][0]["address"], "0xabc")
            self.assertEqual(cfg["validation"]["min_score"], 60)  # defaults kept


if __name__ == "__main__":
    unittest.main()
