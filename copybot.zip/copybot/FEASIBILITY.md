# Feasibility report (checked October 2026)

| Source | Verdict | Why |
|---|---|---|
| **On-chain wallets, Base + Arbitrum** | ✅ Built (primary) | Every swap is public. Alchemy's free tier covers both chains for live log subscriptions and wallet history. Gas is a few cents, so £15–£25 trades are viable. |
| On-chain, Ethereum mainnet | ❌ Excluded | Gas regularly costs more than the round-trip on a £20 trade, and public-mempool sandwich attacks are common. |
| On-chain, Solana | ⏸ Later | Mostly memecoins and sniper bots, the hardest wallets to copy profitably. Needs a separate decoder (Helius). Add once the EVM version proves itself. |
| **Hyperliquid** | ⏸ Not in v1 | Positions are public via its API, but it's a perpetual-futures venue. The FCA added it to its warning list in June 2026 as unauthorised in the UK, so there's no Ombudsman or FSCS cover. Its signals are mostly leveraged longs/shorts that can't be mirrored with spot tokens. Possible later as a *read-only* sentiment input, never for executing. |
| **eToro** | ⏸ Not in v1 | eToro now has an official Public API (verified account needed). It supports trading your own account and analysing Pro Investors, and the terms forbid commercial redistribution or using it on behalf of third parties. So reading investors for your own use looks allowed. But eToro's own CopyTrader already copies with no delay and no build, and eToro's spread on small crypto trades erodes the edge. **Recommendation:** use CopyTrader directly if you want eToro exposure. A custom adapter is possible later. |
| **Involio** | ❌ Excluded | No public developer API found. Getting trades would mean scraping, which breaks the rules you set. |
| **Bitget / Bybit** | ❌ Not via the bot | Their official copy-trading APIs manage *your own* follower or lead-trader account. Reading other traders' live positions only works through the websites' internal endpoints (third-party scrapers exist), which is scraping. **Recommendation:** use their native copy-trading separately with a small, fixed budget and their own stop-losses. |
| Nansen / Arkham / GMGN / Birdeye | 🟡 Manual input | Full smart-money APIs are paid or unofficial. Use their websites to *find* wallets, then add them with `add-leader`. The bot scores, replays and probations them like any other. |
| GeckoTerminal | ✅ Used | Free, no key, about 30 calls/minute: prices, pools, liquidity, trending pools, minute candles for replays. |
| GoPlus | ✅ Used | Free token-security checks: honeypot, taxes, owner powers, holder concentration, LP locks. |
| CoinGecko | ✅ Used | BTC trend filter, ETH price, USD→GBP rate. A free demo key is optional but avoids throttling. |

## MEV and execution risk

Base and Arbitrum run on a single sequencer with no public mempool like Ethereum's. That makes classic sandwich attacks much rarer, which is a main reason these chains were chosen. Slippage still happens: the bot models it and rejects thin pools. When live execution is added, every swap gets a hard minimum-output limit and is simulated before it's sent.

## UK notes

- **Tax:** each sale or swap of a token is a disposal for Capital Gains Tax. `export-tax` applies HMRC's same-day, 30-day and Section 104 rules to produce an estimate for tax software or an accountant.
- **Regulation:** DEX trading from your own wallet is legal but unregulated. There's no FSCS or Ombudsman if a token rugs or a contract is exploited.
- **Leverage:** the bot is spot-only and has no leverage code at all.

## Sources

- eToro Public API docs: https://api-portal.etoro.com/index.md
- eToro App Store / API terms coverage: https://www.tradeinformer.com/broker-news/etoro-launches-ai-trading-app-store
- Bitget API docs (copy-trade endpoints): https://bitgetlimited.github.io/apidoc/en/copyTrade/
- Bitget leaderboard scraper (shows positions come from internal web endpoints): https://apify.com/brilliant_gum/bitget-scraper.md
- FCA warning on Hyperliquid: https://cryptonews.net/news/legal/32973041/
- GeckoTerminal API limits: https://apiguide.geckoterminal.com/llms-full.txt
